#if !defined( _VERSION_H )
#define _VERSION_H
#define LIBVER  "20.226a"
#define VERSION wxT( "20.226a" )
#define FILEVER 20,226,0,1
#define PRODVER 20,226,0,1
#define STRFILEVER "20.226a\0"
#define STRPRODVER "20.226a\0"
#endif
