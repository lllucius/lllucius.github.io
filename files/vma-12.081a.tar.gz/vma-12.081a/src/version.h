#if !defined( _VERSION_H )
#define _VERSION_H
#define LIBVER  "12.081a"
#define VERSION wxT( "12.081a" )
#define FILEVER 12,080,0,1
#define PRODVER 12,080,0,1
#define STRFILEVER "12.081a\0"
#define STRPRODVER "12.081a\0"
#endif
