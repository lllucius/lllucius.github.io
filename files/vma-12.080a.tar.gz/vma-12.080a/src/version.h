#if !defined( _VERSION_H )
#define _VERSION_H
#define LIBVER  "12.080a"
#define VERSION wxT( "12.080a" )
#define FILEVER 12,080,0,1
#define PRODVER 12,080,0,1
#define STRFILEVER "12.080a\0"
#define STRPRODVER "12.080a\0"
#endif
