/* ====================================================================
||
|| VMAGui - GUI viewer/extractor for VMARC Hives
||
|| This little utility allows you to view and extract subfiles from
|| archives in VMARC format.
||
|| Written by:  Leland Lucius (vma@homerow.net>
||
|| Copyright:  Public Domain (just use your conscience)
||
==================================================================== */

// ====================================================================
// The application
// ====================================================================
class MyApp : public wxApp
{
public:
    MyApp(){};
    bool OnInit();
};

// ====================================================================
// The GUI dialog
// ====================================================================
class MyFrame : public wxFrame
{
public:
    MyFrame();

    void OnCloseWindow( wxCloseEvent& event );
    void OnClose( wxCloseEvent& event );
    void OnQuit( wxCommandEvent& event );
    void OnCtrlA( wxCommandEvent& event );
    void OnEnter( wxCommandEvent& event );
    void OnOpen( wxCommandEvent& event );
    void OnExtract( wxCommandEvent& event );
    void OnExtAll( wxCommandEvent& event );
    void OnView( wxCommandEvent& event );
    void OnSettings( wxCommandEvent& event );
    void OnColumnClick( wxListEvent& event );
    void OnActivated( wxListEvent& event );

private:
    wxStatusBar     *m_Status;
    wxPanel         *m_panel;
    wxButton        *m_Open;
    wxButton        *m_Extract;
    wxButton        *m_ExtAll;
    wxButton        *m_View;
    wxButton        *m_Settings;

    wxTextCtrl      *m_Pattern;

    wxRadioButton   *m_Auto;
    wxRadioButton   *m_Text;
    wxRadioButton   *m_Binary;

    wxListView      *m_List;

    enum Format
    {
        FmtAuto = 0,
        FmtText,
        FmtBinary
    };

    enum Field
    {
        Fn = 0,
        Ft,
        Fm,
        Date,
        Recfm,
        Lrecl,
        Ibytes,
        Obytes,
        Verrel,
        Method,
        Dtype
    };


    void LoadSettings( void );
    void SaveSettings( void );

    bool OpenArchive( char *name = NULL );
    bool Extract( SUBFILE *sf, wxString dest, int nItem );

    void AutoSizeColumns( void );
    wxString Format( SUBFILE *sf, int nField );
    wxString OutputName( SUBFILE *sf );
    static int wxCALLBACK Compare( long item1, long item2, long sortData );

    void *m_vma;
    wxConfigBase *m_Config;

    wxString m_Filename;
    wxString m_OpenPath;
    wxString m_SavePath;
    wxString m_FromUCM;
    wxString m_ToUCM;
    wxString m_TxtViewer;
    wxString m_BinViewer;
    wxString m_Filter;
    wxString m_Msg;
    wxString m_Action;
    bool m_Stats;
    int m_Format;

    int m_ImageUnknown;
    int m_ImageText;
    int m_ImageBinary;
    int m_ImageUp;
    int m_ImageDown;

    SUBFILE *m_sf;
    Field m_SortBy;
    int m_Dir;

    wxImageList *m_Images;

#if defined( DEBUG )
    wxLogWindow *m_Log;
#endif

    DECLARE_EVENT_TABLE()
};

// controls and menu constants
enum
{
    ID_OPEN = 101,
    ID_EXTRACT,
    ID_EXTALL,
    ID_VIEW,
    ID_SETTINGS,

    ID_OUTPAT,

    ID_AUTO,
    ID_TEXT,
    ID_BINARY,

    ID_LIST,

    ID_ENTER,
    ID_CTRL_A
};

// ====================================================================
// A little class to allow us to get rid of the temporary file when the
// viewing app completes.
//
// NOTE:  If the user closes VMAGui before closing the viewer app, the
//        temporary file will not get deleted.  This could be solved
//        by not allowing VMAGui to terminate until all viewers had
//        terminated.
// ====================================================================
class MyProcess : public wxProcess
{
public:
    MyProcess( const wxString& temp )
    {
        m_Temp = temp;
    }

    //
    // Override OnTerminate() to delete temp file when command completes
    //
    void OnTerminate( int WXUNUSED( pid ), int WXUNUSED( status ) )
    {
        wxRemoveFile( m_Temp );
    }

private:
    wxString m_Temp;
};
