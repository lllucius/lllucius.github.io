/* ====================================================================
||
|| VMAGui - GUI viewer/extractor for VMARC Hives
||
|| This little utility allows you to view and extract subfiles from
|| archives in VMARC format.
||
|| Written by:  Leland Lucius (vma@homerow.net>
||
|| Copyright:  Public Domain (just use your conscience)
||
==================================================================== */

// ====================================================================
// headers
// ====================================================================

// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include <wx/wx.h>
#endif

#include <wx/listctrl.h>
#include <wx/filename.h>
#include <wx/busyinfo.h>
#include <wx/config.h>
#include <wx/tokenzr.h>
#include <wx/process.h>

#include "src/vma.h"
#include "version.h"
#include "vmagui.h"
#include "settings.h"

// ====================================================================
// pixmaps
// ====================================================================
#include "res/vmagui.xpm"
#include "res/unknown16.xpm"
#include "res/text16.xpm"
#include "res/binary16.xpm"
#include "res/uparrow16.xpm"
#include "res/downarrow16.xpm"

#if !defined( MAX )
#define MAX( a, b ) ( ( a ) > ( b ) ? ( a ) : ( b ) )
#endif

#if defined( DEBUG )
#define log wxLogMessage
#else
#define log
#endif

// ====================================================================
// We are an application (no, really, we are.)
// ====================================================================
IMPLEMENT_APP( MyApp )

// ====================================================================
// Main entry method
// ====================================================================
bool MyApp::OnInit()
{
    MyFrame *frame = new MyFrame;

    // Display the dialog
    frame->Show( true );

    // Make sure our's is on top
    SetTopWindow( frame );

    return true;
}

// ====================================================================
// Event table
// ====================================================================
BEGIN_EVENT_TABLE( MyFrame, wxFrame )
    //
    // Window handlers
    //
    EVT_CLOSE(                              MyFrame::OnClose        )

    //
    // Button handlers
    //
    EVT_BUTTON(                 ID_OPEN,    MyFrame::OnOpen         )
    EVT_BUTTON(                 ID_EXTRACT, MyFrame::OnExtract      )
    EVT_BUTTON(                 ID_EXTALL,  MyFrame::OnExtAll       )
    EVT_BUTTON(                 ID_VIEW,    MyFrame::OnView         )
    EVT_BUTTON(                 ID_SETTINGS,MyFrame::OnSettings     )

    //
    // Listview handlers
    //
    EVT_LIST_COL_CLICK(         ID_LIST,    MyFrame::OnColumnClick  )
    EVT_LIST_ITEM_ACTIVATED(    ID_LIST,    MyFrame::OnActivated    )

    //
    // Accelerator handlers
    //
    EVT_MENU(                   wxID_EXIT,  MyFrame::OnQuit         )
    EVT_MENU(                   ID_CTRL_A,  MyFrame::OnCtrlA        )
END_EVENT_TABLE()

// ====================================================================
// Constructor
// ====================================================================
MyFrame::MyFrame()
    : wxFrame( NULL,
               wxID_ANY,
               _T( "VMAGui - VMARC Viewer/Extractor - Version " VERSION ),
               wxDefaultPosition,
               wxDefaultSize,
               wxDEFAULT_FRAME_STYLE | wxNO_FULL_REPAINT_ON_RESIZE )
{

#if defined( DEBUG )
    m_Log = new wxLogWindow( this, "Log" );
#endif

    // Get access to our config manager
    m_Config = wxConfig::Get();

    // Set to record all defaults
    m_Config->SetRecordDefaults();

    // Add our cut little teddy icon
    SetIcon( wxICON( vmagui ) );

    // Create a nice little status bar
    {
        wxString v = "v" VERSION;
        wxCoord w, h;
        int ws[ 2 ];

        GetTextExtent( v, &w, &h );
        ws[ 0 ] = -1;
        ws[ 1 ] = w + 20;
        
        m_Status = CreateStatusBar( 2 );

        SetStatusWidths( 2, ws );

        SetStatusText( _T( "" ), 0 );
        SetStatusText( v, 1 );
    }

    // Use a panel to get automatic TAB handling
    wxPanel *p = new wxPanel( this, -1 );
  
    // Create base sizer
    wxBoxSizer *szBase = new wxBoxSizer( wxVERTICAL );

    // Create the top sizer
    wxBoxSizer *szTop = new wxBoxSizer( wxHORIZONTAL );

    // Create the button grouping
    wxBoxSizer *szButtons = new wxBoxSizer( wxHORIZONTAL );
    m_Open = new wxButton( p,
                           ID_OPEN,
                           _T( "&Open" ) );
    szButtons->Add( m_Open,
                    wxSizerFlags().Border( wxLEFT | wxRIGHT, 2 ) );

    m_Extract = new wxButton( p,
                           ID_EXTRACT,
                           _T( "&Extract" ) );
    szButtons->Add( m_Extract,
                    wxSizerFlags().Border( wxLEFT | wxRIGHT, 2 ) );

    m_ExtAll = new wxButton( p,
                           ID_EXTALL,
                           _T( "Extract &All" ) );
    szButtons->Add( m_ExtAll,
                    wxSizerFlags().Border( wxLEFT | wxRIGHT, 2 ) );

    m_View = new wxButton( p,
                           ID_VIEW,
                           _T( "&View" ) );
    szButtons->Add( m_View,
                    wxSizerFlags().Border( wxLEFT | wxRIGHT, 2 ) );

    m_Settings = new wxButton( p,
                               ID_SETTINGS,
                               _T( "&Settings" ) );
    szButtons->Add( m_Settings,
                    wxSizerFlags().Border( wxLEFT | wxRIGHT, 2 ) );

    szTop->Add( szButtons,
                wxSizerFlags().Center().Border( wxALL, 5 ) );

    // Add some cushion
    szTop->AddStretchSpacer();

    // Create the output pattern grouping
    wxBoxSizer *szPattern = new wxBoxSizer( wxHORIZONTAL );

    wxStaticText *text = new wxStaticText( p,
                                           wxID_ANY,
                                           _T( "&Pattern:" ) );
    szPattern->Add( text,
                    wxSizerFlags().Center() );

    m_Pattern = new wxTextCtrl( p,
                               ID_OUTPAT,
                               _T( "%n.%t.%m" ),
                               wxDefaultPosition,
                               wxSize( -1, 20 ) );
    szPattern->Add( m_Pattern,
                    wxSizerFlags().Center() );

    szTop->Add( szPattern,
                wxSizerFlags().Center().Border( wxALL, 5 ) );

    // Add some cushion
    szTop->AddStretchSpacer();

    // Create the extraction type grouping
    wxBoxSizer *szType = new wxBoxSizer( wxHORIZONTAL );

    m_Auto = new wxRadioButton( p,
                                ID_AUTO,
                                _T( "A&uto" ) );
    szType->Add( m_Auto,
                 wxSizerFlags().Align( wxALIGN_RIGHT | wxALIGN_CENTER_VERTICAL ) );

    m_Text = new wxRadioButton( p,
                                ID_TEXT,
                                _T( "&Text" ) );
    szType->Add( m_Text,
                 wxSizerFlags().Align( wxALIGN_RIGHT | wxALIGN_CENTER_VERTICAL ) );

    m_Binary = new wxRadioButton( p,
                                  ID_BINARY,
                                  _T( "&Binary" ) );
    szType->Add( m_Binary,
                 wxSizerFlags().Align( wxALIGN_RIGHT | wxALIGN_CENTER_VERTICAL ) );

    szTop->Add( szType,
                wxSizerFlags().Center().Border( wxALL, 5 ) );

    // Top grouping is complete so add it to the base group
    szBase->Add( szTop, wxSizerFlags().Left().Expand() );

    // Create the subfile list
    m_List = new wxListView( p,
                             ID_LIST );

    m_List->SetSingleStyle( wxLC_SORT_ASCENDING, true );

    // Add it to the base group
    szBase->Add( m_List,
                 wxSizerFlags().Expand().Proportion( 1 ) );

    // Tell the panel about the base sizer
    p->SetSizer( szBase );
  
    // Set initial sizes and establish minimums
    szBase->SetSizeHints( this );

    // Add the list view images
    m_Images       = new wxImageList( 15, 16, true );
    m_ImageUnknown = m_Images->Add( wxIcon( unknown16_xpm ) );
    m_ImageText    = m_Images->Add( wxIcon( text16_xpm ) );
    m_ImageBinary  = m_Images->Add( wxIcon( binary16_xpm ) );
    m_ImageUp      = m_Images->Add( wxIcon( uparrow16_xpm ) );
    m_ImageDown    = m_Images->Add( wxIcon( downarrow16_xpm ) );

    m_List->SetImageList( m_Images, wxIMAGE_LIST_SMALL );

    // Define the list view columns
    m_List->InsertColumn( Fn,       "Fn",           wxLIST_FORMAT_LEFT  );
    m_List->SetColumnImage( Fn,     -1 );

    m_List->InsertColumn( Ft,       "Ft",           wxLIST_FORMAT_LEFT  );
    m_List->SetColumnImage( Ft,     -1 );

    m_List->InsertColumn( Fm,       "Fm",           wxLIST_FORMAT_LEFT  );
    m_List->SetColumnImage( Fm,     -1 );

    m_List->InsertColumn( Date,     "Date",         wxLIST_FORMAT_LEFT  );
    m_List->SetColumnImage( Date,   -1 );

    m_List->InsertColumn( Recfm,    "Recfm",        wxLIST_FORMAT_LEFT  );
    m_List->SetColumnImage( Recfm,  -1 );

    m_List->InsertColumn( Lrecl,    "Lrecl",        wxLIST_FORMAT_RIGHT );
    m_List->SetColumnImage( Lrecl,  -1 );

    m_List->InsertColumn( Ibytes,   "Bytes in",     wxLIST_FORMAT_RIGHT );
    m_List->SetColumnImage( Ibytes, -1 );

    m_List->InsertColumn( Obytes,   "Bytes out",    wxLIST_FORMAT_RIGHT );
    m_List->SetColumnImage( Obytes, -1 );

    m_List->InsertColumn( Verrel,   "V.R",          wxLIST_FORMAT_LEFT  );
    m_List->SetColumnImage( Verrel, -1 );

    m_List->InsertColumn( Method,   "Method",       wxLIST_FORMAT_LEFT  );
    m_List->SetColumnImage( Method, -1 );

    m_List->InsertColumn( Dtype,    "Type",         wxLIST_FORMAT_LEFT  );
    m_List->SetColumnImage( Dtype,  -1 );

    // Set initial sort order
    m_Dir = 1;
    m_SortBy = Fn;

    // Define accelerators
    wxAcceleratorEntry ae[ 2 ];

    ae[ 0 ].Set( wxACCEL_NORMAL, WXK_ESCAPE, wxID_EXIT );
    ae[ 1 ].Set( wxACCEL_CTRL,   (int) 'A',  ID_CTRL_A );

    wxAcceleratorTable at( 2, ae );

    SetAcceleratorTable( at );

    // Load preferences
    LoadSettings();

    // Process command line arguments
    if( wxTheApp->argc == 2 )
    {
        // Just open and display the hive contents
        OpenArchive( wxTheApp->argv[ 1 ] );
    }
    else if( wxTheApp->argc == 3 )
    {
        // Direct extraction?
        if( strcmp( wxTheApp->argv[ 1 ], "/x" ) == 0 )
        {
            // Open and extract contents
            if( OpenArchive( wxTheApp->argv[ 2 ] ) )
            {
                wxCommandEvent event;
                OnExtAll( event );
            }

            // Display messages in box as we will be exiting
            wxString msg = m_Status->GetStatusText();
            if( !msg.IsEmpty() )
            {
                wxMessageBox( msg, "Helpful Message" );
            }

            // We're done so kill the dialog
            Destroy();

            return;
        }
    }

    return;
}

// ====================================================================
// Handle column header clicks
// ====================================================================
void MyFrame::OnColumnClick( wxListEvent& event )
{
    int SortBy = event.GetColumn();

    // Get rid of previous arrow, if any.
    m_List->ClearColumnImage( m_SortBy );

    // Determine direction
    if( m_SortBy == SortBy )
    {
        m_Dir = -   m_Dir;
    }
    else
    {
        m_Dir = 1;
        m_SortBy = static_cast<Field> (SortBy)  ;
    }

    // Sort the items
    m_List->SortItems( Compare, ( m_SortBy + 1 ) * m_Dir );

    // And set the direction arrow
    m_List->SetColumnImage( m_SortBy,
                            m_Dir < 0 ? m_ImageDown : m_ImageUp );

    return;
}

// ====================================================================
// A list item was activated (double clicked or ENTER pressed)
// ====================================================================
void MyFrame::OnActivated( wxListEvent& event )
{

    // Simulate a left button click based on default action
    if( m_Action.Cmp( "View" ) == 0 )
    {
        OnView( event );
    }
    else
    {
        OnExtract( event );
    }

    return;
}

// ====================================================================
// Close our dialog when asked to quit
// ====================================================================
void MyFrame::OnQuit( wxCommandEvent& WXUNUSED( event ) )
{
    Close( true );

    return;
}

// ====================================================================
// CTRL+A was press, so select everything for list view and edit box
// ====================================================================
void MyFrame::OnCtrlA( wxCommandEvent& WXUNUSED( event ) )
{
    int nItem = 0;

    // Get ID of currently focused control
    switch( FindFocus()->GetId() )
    {
        // It's the list view
        case ID_LIST:

            // Look through all items
            while( TRUE )
            {
                // Get the next item
                nItem = m_List->GetNextItem( nItem );
                if( nItem == -1 )
                {
                    break;
                }
    
                // And select it
                m_List->Select( nItem, true );
            }

        break;

        // Pattern edit box
        case ID_OUTPAT:

            // Select entire contents
            m_Pattern->SetSelection( -1, -1 );

        break;
    }

    return;
}

// ====================================================================
// Shutting down so save settings and destroy dialog
// ====================================================================
void MyFrame::OnClose( wxCloseEvent& WXUNUSED( event ) )
{
    // Save the settings
    SaveSettings();

    // Destroy dialog
    Destroy();

    return;
}

// ====================================================================
// Open button clicked
// ====================================================================
void MyFrame::OnOpen( wxCommandEvent& WXUNUSED( event ) )
{

    // Go open an archive
    OpenArchive();

    return;
}

// ====================================================================
// Extract button clicked
// ====================================================================
void MyFrame::OnExtract( wxCommandEvent& WXUNUSED( event ) )
{
    SUBFILE *sf;
    wxFileName fn;
    wxString dest;
    int nItem;
    int cnt = m_List->GetSelectedItemCount();

    // Can't do anything without entries
    if( m_List->GetItemCount() == 0 )
    {
		wxMessageBox( "Might be a good idea if you opened a VMARC "
                      "before trying to extract anything.",
                      "Here's you sign...",
                      wxICON_EXCLAMATION );

        return;
    }

    // Can't do anything without selections
    if( cnt == 0 )
    {
		wxMessageBox( "I'm just thinkin' here, but maybe, just maybe, "
                      "selecting something might work a little better?",
                      "Here's your sign..." );

        return;
    }

    // Only one file selected...handle it
    if( cnt == 1 )
    {
        // Get the first (only) selected item
        nItem = m_List->GetFirstSelected();

        // And the SUBFILE ptr
        sf = (SUBFILE *) m_List->GetItemData( nItem );

        // Generate an output name and append to previous folder path
        fn = m_SavePath;
        fn.AppendDir( OutputName( sf ) );

        // Create an Open dialog
        wxFileDialog fd( this,
                         "Specify the output file name",
                         m_SavePath,
                         OutputName( sf ),
                         "All Files|*.*",
                         wxSAVE | wxOVERWRITE_PROMPT );

        // And Display it
        if( fd.ShowModal() != wxID_OK )
        {
            return;
        }

        // Retrieve the (possibly updated) file name
        fn = fd.GetPath();

        // Remember the folder part
        m_SavePath = fn.GetPath();

        // Extract it
        Extract( sf, fn.GetFullPath(), nItem );

        return;
    }

    // Create the "Browse for Folder" dialog
    wxDirDialog dd( this,
                    "Choose a directory",
                    m_SavePath,
                    wxDD_DEFAULT_STYLE );

    // And display it
    if( dd.ShowModal() != wxID_OK )
    {
        return;
    }

    // Remember the path
    m_SavePath = dd.GetPath();

    // Keep this as a separate block for the wxBusyInfo
    {
        wxBusyInfo wait( "Extracting files..." );

        // Retrieve the first selected item
        cnt = 0;
        nItem = -1;
        while( TRUE )
        {
            nItem = m_List->GetNextItem( nItem );
            if( nItem == -1 )
            {
                break;
            }

            // And the SUBFILE ptr
            sf = (SUBFILE *) m_List->GetItemData( nItem );
    
            // Generate an output name and append to previous folder path
            fn.Assign( m_SavePath, OutputName( sf ) );
    
            // Extract it
            if( !Extract( sf, fn.GetFullPath(), nItem ) )
            {
                break;
            }
    
            cnt++;
        }
    }
    
    // Provide a little info
    m_Msg.Printf( " %d subfiles extracted", cnt );
    SetStatusText( m_Msg );

    return;
}

// ====================================================================
// Extract All button clicked
// ====================================================================
void MyFrame::OnExtAll( wxCommandEvent& WXUNUSED( event ) )
{
    SUBFILE *sf;
    wxFileName fn;
    wxString dest;
    int nItem;
    int cnt;

    // Can't do anything without entries
    if( m_List->GetItemCount() == 0 )
    {
		wxMessageBox( "Might be a good idea if you opened a VMARC "
                      "before trying to extract anything.",
                      "Here's you sign...",
                      wxICON_EXCLAMATION );

        return;
    }

    // Create the "Browse for Folder" dialog
    wxDirDialog dd( this,
                    "Choose a directory",
                    m_SavePath,
                    wxDD_DEFAULT_STYLE );

    // And display it
    if( dd.ShowModal() != wxID_OK )
    {
        return;
    }

    // Remember the path
    m_SavePath = dd.GetPath();

    // Keep this as a separate block for the wxBusyInfo
    {
        wxBusyInfo wait( "Extracting files..." );

        // Retrieve the first selected item
        cnt = 0;
        nItem = -1;
        while( TRUE )
        {
            nItem = m_List->GetNextItem( nItem );
            if( nItem == -1 )
            {
                break;
            }

            // And the SUBFILE ptr
            sf = (SUBFILE *) m_List->GetItemData( nItem );
    
            // Generate an output name and append to previous folder path
            fn.Assign( m_SavePath, OutputName( sf ) );
    
            // Extract it
            if( !Extract( sf, fn.GetFullPath(), nItem ) )
            {
                break;
            }
    
            cnt++;
        }
    }
    
    // Provide a little info
    m_Msg.Printf( " %d subfiles extracted", cnt );
    SetStatusText( m_Msg );

    return;
}

// ====================================================================
// View button clicked
// ====================================================================
void MyFrame::OnView( wxCommandEvent& WXUNUSED( event ) )
{
    SUBFILE *sf;
    wxFileName fn;
    wxString dest;
    wxString cmd;
    int nItem;
    int cnt = m_List->GetSelectedItemCount();

    // Can't do anything without entries
    if( m_List->GetItemCount() == 0 )
    {
		wxMessageBox( "Might be a good idea if you opened a VMARC "
                      "before trying to extract anything.",
                      "Here's you sign...",
                      wxICON_EXCLAMATION );

        return;
    }

    // Can't do anything without selections
    if( cnt == 0 )
    {
		wxMessageBox( "I'm just thinkin' here, but maybe, just maybe, "
                      "selecting something might work a little better?",
                      "Here's your sign..." );

        return;
    }

    // Limit to one file at a time
    if( cnt > 1 )
    {
        wxMessageBox( "I could show you more than 1 file, but I don't feel like it.",
                      "Helpful Message" );
        return;
    }

    // Get the first (only) selected item
    nItem = m_List->GetFirstSelected();

    // And the SUBFILE ptr
    sf = (SUBFILE *) m_List->GetItemData( nItem );

    // Generate an output name and append to previous folder path
    dest = wxFileName::CreateTempFileName( "VMA" );

    // Extract it
    if( !Extract( sf, dest, nItem ) )
    {
        return;
    }

    // Determine how to view the file
    cmd = m_BinViewer;
    if( m_Text->GetValue() || ( m_Auto->GetValue() && sf->dtype == VMAD_TEXT ) )
    {
        cmd = m_TxtViewer;
    }
    
    // Invoke the viewer app
    cmd += " " + dest;
    wxProcess *process = new MyProcess( dest );
    if( wxExecute( cmd, wxEXEC_ASYNC, process ) == 0 )
    {
        wxLogError( _T( "Execution of '%s' failed." ), cmd.c_str() );

        delete process;
    }

    return;
}

// ====================================================================
// Settings button clicked
// ====================================================================
void MyFrame::OnSettings( wxCommandEvent& WXUNUSED( event ) )
{
    Settings settings( this );
    wxString exts;
    wxString ext;
    int rc;

    // Display Settings dialog
    settings.ShowModal();

    // Refresh (possibly changed) settings
    m_Stats = m_Config->Read( _T( "Subfile Stats" ), true );

    m_Action = m_Config->Read( _T( "Default Action" ), "View" );

    m_TxtViewer = m_Config->Read( _T( "Text Viewer" ), _T( "Notepad" ) );

    m_BinViewer = m_Config->Read( _T( "Binary Viewer" ), _T( "Notepad" ) );

    m_FromUCM = m_Config->Read( _T( "From UCM" ), _T( "" ) );

    m_ToUCM = m_Config->Read( _T( "To UCM" ), _T( "" ) );

    exts = m_Config->Read( _T( "Extensions" ), _T( ".vma;.vmarc" ) );

    // Rebuild Open dialog filter
    m_Filter.Empty();

    wxStringTokenizer st( exts, _T( ";" ) );

    // Make sure extension have proper format
    while( st.HasMoreTokens() )
    {
        ext = st.GetNextToken().Strip( wxString::both );
        if( ext.Length() == 0 )
        {
            continue;
        }
        if( ext[ 0 ] == '*' )
        {
            ext.Remove( 0, 1 );
        }

        if( ext[ 0 ] == '.' )
        {
            ext.Remove( 0, 1 );
        }

        m_Filter += "*." + ext + ';';
    }

    // Complete filter if extensions provided
    if( !m_Filter.IsEmpty() )
    {
        m_Filter = "VMARC Hives|" + m_Filter + '|';
    }

    // Reset the conversion tables
    if( m_vma )
    {
        // Both UCMs must be specified to 
        if( !m_FromUCM.IsEmpty() && !m_ToUCM.IsEmpty() )
        {
            rc = vma_setconv( m_vma,
                              m_FromUCM,
                              m_ToUCM );

            if( rc != VMAE_NOERR )
            {
                exts.Printf( "Conversion table load failed: %d, %s\n",
                             rc,
                             vma_strerror( rc ) );

                wxMessageBox( exts, "Not So Helpful Message" );
            }
        }
        else
        {
            // Reset to internal conversion
            vma_setconv( m_vma, NULL, NULL );
        }
    }

    return;
}

// ====================================================================
// MyFrame private methods
// ====================================================================

// ====================================================================
// Compare function for column sorting
// ====================================================================
int wxCALLBACK
MyFrame::Compare( long item1,
                  long item2, 
                  long sortData )
{
    SUBFILE *sf1 = reinterpret_cast<SUBFILE *>(item1);
    SUBFILE *sf2 = reinterpret_cast<SUBFILE *>(item2);
    bool    dir = false;
    int     result = 0;

    // Descending?
    if( sortData < 0 )
    {
        sortData = -sortData;
        dir = true;
    }

    // Compare entries based on column
    switch( sortData - 1 )
    {
        case Fn:
            result = strcasecmp( (char *)sf1->fn, (char *)sf2->fn );
        break;

        case Ft:
            result = strcasecmp( (char *)sf1->ft, (char *)sf2->ft );
        break;

        case Fm:
            result = strcasecmp( (char *)sf1->fm, (char *)sf2->fm );
        break;

        case Date:
            {
                struct tm bt;
                time_t ct1;
                time_t ct2;

                // Convert time of first entry
                bt.tm_sec = sf1->second;
                bt.tm_min = sf1->minute;
                bt.tm_hour = sf1->hour;
                bt.tm_mday = sf1->day;
                bt.tm_mon = sf1->month;
                bt.tm_year = sf1->year - 1900;
                bt.tm_wday = 0;
                bt.tm_yday = 0;
                bt.tm_isdst = 0;
            
                ct1 = mktime( &bt );

                // Convert time of second entry
                bt.tm_sec = sf2->second;
                bt.tm_min = sf2->minute;
                bt.tm_hour = sf2->hour;
                bt.tm_mday = sf2->day;
                bt.tm_mon = sf2->month;
                bt.tm_year = sf2->year - 1900;
                bt.tm_wday = 0;
                bt.tm_yday = 0;
                bt.tm_isdst = 0;
            
                ct2 = mktime( &bt );

                result = static_cast<int>(ct1 - ct2);
        }
        break;

        case Recfm:
            result = sf1->recfm - sf2->recfm;
        break;

        case Lrecl:
            result = sf1->lrecl - sf2->lrecl;
        break;

        case Ibytes:
            result = sf1->ibytes - sf2->ibytes;
        break;

        case Obytes:
            result = sf1->obytes - sf2->obytes;
        break;

        case Verrel:
            result =  ( ( sf1->ver << 8 ) + sf1->rel ) -
                      ( ( sf2->ver << 8 ) + sf2->rel );
        break;

        case Method:
            result = strcasecmp( (char *)sf1->meth, (char *)sf2->meth );
        break;

        case Dtype:
            result = strcasecmp( (char *)sf1->meth, (char *)sf2->meth );
        break;
    }

    return dir ? -result : result;
}

// ====================================================================
// Format function for list values
// ====================================================================
wxString MyFrame::Format( SUBFILE *sf, int nField )
{
    wxString szResult;

    // Populate szResult based on column
    switch( nField )
    {
        case Fn:
            szResult = sf->fn;
        break;

        case Ft:
            szResult = sf->ft;
        break;

        case Fm:
            szResult = sf->fm;
        break;

        case Date:
            szResult.Printf( "%04d/%02d/%02d %02d:%02d:%02d",
                             sf->year,
                             sf->month,
                             sf->day,
                             sf->hour,
                             sf->minute,
                             sf->second );
        break;

        case Recfm:
            szResult.Printf( "%c", sf->recfm );
        break;

        case Lrecl:
            szResult.Printf( "%d", sf->lrecl );
        break;

        case Ibytes:
            szResult.Printf( "%d", sf->ibytes );
        break;

        case Obytes:
            szResult.Printf( "%d", sf->obytes );
        break;

        case Verrel:
            szResult.Printf( "%d.%d", sf->ver, sf->rel );
        break;

        case Method:
            szResult = sf->meth;
        break;

        case Dtype:
            switch( sf->dtype )
            {
                case VMAD_UNKNOWN:
                    szResult = "Unknown";
                break;

                case VMAD_TEXT:
                    szResult = "Text";
                break;

                case VMAD_BINARY:
                    szResult = "Binary";
                break;
            }
        break;
    }

    return szResult;
}

// ====================================================================
// Auto size columns base on largest of header and entry contents
// ====================================================================
void MyFrame::AutoSizeColumns( void )
{
    int numcols = m_List->GetColumnCount();
    int col;
    int cw1;
    int cw2;

    // Turn off display updating
    m_List->Freeze();

    // Process all columns
    for( col = 0; col < numcols; col++ )
    {
        // Set width based on entry contents
        m_List->SetColumnWidth( col, wxLIST_AUTOSIZE );

        // Retrieve calculated width
        cw1 = m_List->GetColumnWidth( col );

        // Set width base on header contents
        m_List->SetColumnWidth( col, wxLIST_AUTOSIZE_USEHEADER );

        // Retrieve calculated width
        cw2 = m_List->GetColumnWidth( col );

        // Set final width using maximum of the 2 (40 pixel minimum)
        m_List->SetColumnWidth( col, MAX( 40, MAX( cw1, cw2 ) ) );
    }

    // Re-enable display updates
    m_List->Thaw();

    return;
}

// ====================================================================
// Generate output file name using pattern
// ====================================================================
wxString MyFrame::OutputName( SUBFILE *sf )
{
    wxString pat;
    wxString name;
    wxString temp;
    const wxChar *p;

    // Get current pattern
    pat = m_Pattern->GetValue();

    // Build name while examining pattern
    p = pat;
    while( *p )
    {
        // Conversion?
        if( *p == '%' )
        {
            // Is it one we understand?
            p++;
            switch( *p )
            {
                // "%" as end of string
                case '\0':
                    name += '%';
                break;

                // Append lowercase file name
                case 'n':
                    temp = (char *)sf->fn;
                    temp.MakeLower();
                    name += temp;
                break;

                // Append uppercase file name
                case 'N':
                    temp = (char *)sf->fn;
                    temp.MakeUpper();
                    name += temp;
                break;

                // Append lowercase file type
                case 't':
                    temp = (char *)sf->ft;
                    temp.MakeLower();
                    name += temp;
                break;

                // Append uppercase file type
                case 'T':
                    temp = (char *)sf->ft;
                    temp.MakeUpper();
                    name += temp;
                break;

                // Append lowercase file mode
                case 'm':
                    temp = (char *)sf->fm;
                    temp.MakeLower();
                    name += temp;
                break;

                // Append uppercase file mode
                case 'M':
                    temp = (char *)sf->fm;
                    temp.MakeUpper();
                    name += temp;
                break;

                // Just pass through unknowns
                default:
                    name += '%';
                    name += *p;
                break;
            }
        }
        else
        {
            // Append literal character
            name += *p;
        }

        p++;
    }
    
    return name;
}
        
// ====================================================================
// Extract subfile
// ====================================================================
bool MyFrame::Extract( SUBFILE *sf, wxString dest, int nItem )
{
    int mode;
    int rc;

    // Determine the extraction mode
    mode = VMAX_AUTO;
    if( m_Text->GetValue() )
    {
        mode = VMAX_TEXT;
    }
    else if( m_Binary->GetValue() )
    {
        mode = VMAX_BINARY;
    }

    // Users don't like sitting in the dark
    m_Msg.Printf( " Extracting %s.%s.%s",
                  sf->fn,
                  sf->ft,
                  sf->fm );
    SetStatusText( m_Msg );

    // Make this the active subfile
    vma_setactive( m_vma, sf );

    // Extract it
    rc = vma_extract( m_vma, dest, mode );

    // Complain if there was an error
    if( rc != VMAE_NOERR )
    {
        m_Msg.Printf( " Extraction of %s.%s.%s failed with %d, %s",
                      sf->fn,
                      sf->ft,
                      sf->fm,
                      rc,
                      vma_strerror( rc ) );

        wxMessageBox( m_Msg, "Not So Helpful Message" );

        SetStatusText( m_Msg );

        return false;
    }

    // Refresh stats for this entry since they are now available
    m_List->SetItem( nItem, Ibytes, Format( sf, Ibytes ) );
    m_List->SetItem( nItem, Obytes, Format( sf, Obytes ) );
    m_List->SetItem( nItem, Dtype,  Format( sf, Dtype  ) );
    m_List->SetItemImage( nItem, sf->dtype );

    // Unselect the list item
    m_List->SetItemState( nItem, 0, wxLIST_STATE_SELECTED );

    // A silly little message
    m_Msg.Printf( " %s.%s.%s extracted",
                  sf->fn,
                  sf->ft,
                  sf->fm );
    SetStatusText( m_Msg );

    return true;
}

// ====================================================================
// Open an archive
// ====================================================================
bool MyFrame::OpenArchive( char *name )
{
    wxFileName fn;
    SUBFILE *sf;
    int rc;

    // Ask user for filename if one wasn't specified
    if( name == NULL )
    {
        wxFileDialog fd( this,
                         "Choose a VMARC Hive",
                         m_OpenPath,
                         "",
                         m_Filter + "All Files|*.*" );

        if( fd.ShowModal() != wxID_OK )
        {
            return false;
        }

        m_Filename = fd.GetPath();
    }
    else
    {
        m_Filename = name;
    }

    // Normalize path and extract components
    fn = m_Filename;
    fn.Normalize();
    m_Filename = fn.GetFullPath();
    m_OpenPath = fn.GetPath();

    // Close previous archive (if any)
    if( m_vma )
    {
        vma_close( m_vma );
        m_vma = NULL;
    }

    // Get rid of any previous list items
    m_List->DeleteAllItems();

    // Keep this as a separate block for the wxBusyInfo
    {
        wxBusyInfo wait( "Opening VMARC Hive..." );
 
        // Open the new archive
        rc = vma_open( m_Filename, m_Stats, &m_vma );
        if( rc != VMAE_NOERR )
        {
            m_Msg.Printf( "Open failed - rc: %d, %s\n",
                          rc,
                          vma_strerror( rc ) );

            wxMessageBox( m_Msg, "Not So Helpful Message" );

            return false;
        }

        // Set the conversion tables
        if( !m_FromUCM.IsEmpty() && !m_ToUCM.IsEmpty() )
        {
            rc = vma_setconv( m_vma,
                              m_FromUCM,
                              m_ToUCM );

            if( rc != VMAE_NOERR )
            {
                m_Msg.Printf( "Conversion table load failed: %d - %s\n",
                              rc,
                              vma_strerror( rc ) );

                wxMessageBox( m_Msg, "Not So Helpful Message" );

                vma_close( m_vma );
                m_vma = NULL;

                return false;
            }
        }
        else
        {
            // Reset to internal conversion
            vma_setconv( m_vma, NULL, NULL );
        }

        // Add each subfile to the list
        for( rc = vma_first( m_vma, &sf );
            rc == VMAE_NOERR;
            rc = vma_next( m_vma, &sf ) )
        {
            int nIndex;
            wxListItem li;

            li.Clear();
            li.SetId( m_List->GetItemCount() );
            li.SetText( (char *) sf->fn );
            li.SetData( sf );
            li.SetImage( sf->dtype );

            nIndex = m_List->InsertItem( li );
            if( nIndex >= 0 )
            {
                m_List->SetItemData( nIndex, (long) sf );

                m_List->SetItem( nIndex, Ft,     Format( sf, Ft     ) );
                m_List->SetItem( nIndex, Fm,     Format( sf, Fm     ) );
                m_List->SetItem( nIndex, Date,   Format( sf, Date   ) );
                m_List->SetItem( nIndex, Recfm,  Format( sf, Recfm  ) );
                m_List->SetItem( nIndex, Lrecl,  Format( sf, Lrecl  ) );
                m_List->SetItem( nIndex, Ibytes, Format( sf, Ibytes ) );
                m_List->SetItem( nIndex, Obytes, Format( sf, Obytes ) );
                m_List->SetItem( nIndex, Verrel, Format( sf, Verrel ) );
                m_List->SetItem( nIndex, Method, Format( sf, Method ) );
                m_List->SetItem( nIndex, Dtype,  Format( sf, Dtype  ) );
            }
        }

        //
        // Check final status
        //
        if( rc != VMAE_NOMORE )
        {
            m_Msg.Printf( "Subfile processing failed - rc: %d, %s\n",
                          rc,
                          vma_strerror( rc ) );
    
            wxMessageBox( m_Msg, "Not So Helpful Message" );
    
            vma_close( m_vma );
            m_vma = NULL;

            return false;
        }
    
        m_List->SortItems( Compare, m_SortBy );
        AutoSizeColumns();
    };

    // Finally, set the window title
    m_Msg.Printf( "VMAWin - %s", m_Filename.c_str() );
    SetTitle( m_Msg );

    return true;
}

// ====================================================================
// Save profile settings
// ====================================================================
void MyFrame::SaveSettings( void )
{
    wxRect rect;

    // Set active subkey
    m_Config->SetPath( "/Settings" );

    // Write all the settings
    m_Config->Write( "Open Path",
                     m_OpenPath );

    m_Config->Write( "Save Path",
                     m_SavePath );

    m_Format = VMAX_AUTO;
    if( m_Text->GetValue() )
    {
        m_Format = VMAX_TEXT;
    }
    else if( m_Binary->GetValue() )
    {
        m_Format = VMAX_BINARY;
    }
    
    m_Config->Write( "Format",
                     m_Format );

    m_Config->Write( "Pattern",
                     m_Pattern->GetValue() );

    m_Config->Write( "Maximized",
                     IsMaximized() );

    // Must "restore" window to get actual dimensions
    if( IsMaximized() )
    {
        // Prevent visual updating
        Freeze();

        // "Restore" window
        Iconize( false ); 

        // Get dimensions
        rect = GetRect();

        // Put it back the way it was
        Maximize( true ); 

        // Allow visual updating
        Thaw();
    }
    else
    {
        // Get Dimensions
        rect = GetRect();
    }

    // Write the dimensions
    m_Config->Write( _T( "Window X" ),
                     rect.GetX() );
    m_Config->Write( _T( "Window Y" ),
                         rect.GetY() );
    m_Config->Write( _T( "Window W" ),
                     rect.GetWidth() );
    m_Config->Write( _T( "Window H" ),
                     rect.GetHeight() );

    return;
}

// ====================================================================
// Load profile settings
// ====================================================================
void MyFrame::LoadSettings( void )
{
    wxString str;
    wxString exts;
    wxString ext;

    // Set active subkey
    m_Config->SetPath( "/Settings" );

    // Display a little first time info
    if( m_Config->Read( _T( "First Time" ), 1 ) == 1 )
    {
#if defined( _WIN32 )
        wxMessageBox( "You may want to use the Settings dialog to select the file\n"
                      "extensions you'd like to have associated with VMAGui.",
                      "Welcome to VMAGui" );
#else
        wxMessageBox( "You may want to setup your environment to automatically\n"
                      "execute VMAGui when attempting to launch VMARC hives.",
                      "Welcome to VMAGui" );
#endif
        m_Config->Write( _T( "First Time" ), 0l );
    }

    // Read all the settings
    m_Format = m_Config->Read( _T( "Format" ), 0l );
    if( m_Format == VMAX_TEXT )
    {
        m_Text->SetValue( true );
    }
    else if( m_Format == VMAX_BINARY )
    {
        m_Text->SetValue( true );
    }
    else
    {
        m_Auto->SetValue( true );
    }

    str = m_Config->Read( _T( "Pattern" ), _T( "%n.%t.%m" ) );
    m_Pattern->SetValue( str );

    m_OpenPath = m_Config->Read( _T( "Open Path" ), _T( "." ) );

    m_SavePath = m_Config->Read( _T( "Save Path" ), _T( "." ) );

    m_Stats = m_Config->Read( _T( "Subfile Stats" ), true );

    m_Action = m_Config->Read( _T( "Default Action" ), "View" );

    m_TxtViewer = m_Config->Read( _T( "Text Viewer" ), _T( "Notepad" ) );

    m_BinViewer = m_Config->Read( _T( "Binary Viewer" ), _T( "Notepad" ) );

    m_FromUCM = m_Config->Read( _T( "From UCM" ), _T( "" ) );

    m_ToUCM = m_Config->Read( _T( "To UCM" ), _T( "" ) );

    SetSize( m_Config->Read( _T( "Window X" ), -1l ),
             m_Config->Read( _T( "Window Y" ), -1l ),
             m_Config->Read( _T( "Window W" ), -1l ),
             m_Config->Read( _T( "Window H" ), -1l ) );

    Maximize( m_Config->Read( _T( "Maximized" ), 0l ) );

    exts = m_Config->Read( _T( "Extensions" ), _T( ".vma;.vmarc" ) );

    // Rebuild Open dialog filter
    m_Filter.Empty();

    wxStringTokenizer st( exts, _T( ";" ) );

    // Make sure extension have proper format
    while( st.HasMoreTokens() )
    {
        ext = st.GetNextToken().Strip( wxString::both );
        if( ext.Length() == 0 )
        {
            continue;
        }
        if( ext[ 0 ] == '*' )
        {
            ext.Remove( 0, 1 );
        }

        if( ext[ 0 ] == '.' )
        {
            ext.Remove( 0, 1 );
        }

        m_Filter += "*." + ext + ';';
    }

    // Complete filter if extensions provided
    if( !m_Filter.IsEmpty() )
    {
        m_Filter = "VMARC Hives|" + m_Filter + '|';
    }

    return;
}
