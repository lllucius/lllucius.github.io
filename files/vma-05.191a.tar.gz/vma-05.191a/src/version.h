#if !defined( _VERSION_H )
#define _VERSION_H
#define VERSION "05.191a"
#define FILEVER 05,192,0,1
#define PRODVER 05,192,0,1
#define STRFILEVER "05.191a\0"
#define STRPRODVER "05.191a\0"
#endif
