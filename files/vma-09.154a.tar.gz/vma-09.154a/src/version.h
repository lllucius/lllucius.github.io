#if !defined( _VERSION_H )
#define _VERSION_H
#define LIBVER  "09.154a"
#define VERSION wxT( "09.154a" )
#define FILEVER 09,154,0,1
#define PRODVER 09,154,0,1
#define STRFILEVER "09.154a\0"
#define STRPRODVER "09.154a\0"
#endif
