/* ====================================================================
||
|| VMAGui - GUI viewer/extractor for VMARC Hives
||
|| This little utility allows you to view and extract subfiles from
|| archives in VMARC format.
||
|| Written by:  Leland Lucius (vma@homerow.net>
||
|| Copyright:  Public Domain (just use your conscience)
||
==================================================================== */

class Settings : public wxDialog
{
public:
    Settings( wxWindow *parent, int id = -1, wxString title = wxT( "Settings" ) ) ;

    void OnOk( wxCommandEvent& event );
    void OnUpdate( wxCommandEvent& event );
    void OnRemove( wxCommandEvent& event );

    void OnTextBrowse( wxCommandEvent& event );
    void OnBinaryBrowse( wxCommandEvent& event );
    void OnFromBrowse( wxCommandEvent& event );
    void OnToBrowse( wxCommandEvent& event );

private:

    wxTextCtrl      *m_TxtViewer;
    wxTextCtrl      *m_BinViewer;

    wxTextCtrl      *m_Exts;

    wxTextCtrl      *m_FromUCM;
    wxTextCtrl      *m_ToUCM;

    wxComboBox      *m_Action;
    wxCheckBox      *m_Stats;

    wxConfigBase    *m_Config;
    wxLogWindow     *m_Log;

    DECLARE_EVENT_TABLE()
};

enum
{
    ID_TXTBRO = 101,
    ID_BINBRO,
    ID_UPDATE,
    ID_REMOVE,
    ID_FROMBRO,
    ID_TOBRO
};
