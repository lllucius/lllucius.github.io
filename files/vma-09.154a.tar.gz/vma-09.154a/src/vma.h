#if !defined( _VMA_H )
#define _VMA_H

#ifdef __cplusplus
extern "C" {
#endif

/* --------------------------------------------------------------------
|| Subfile information
*/
typedef struct subfile
{
    unsigned char   ver;                /* version of creating VMARC */
    unsigned char   rel;               /* revision of creating VMARC */
    unsigned char   meth[ 5 ];      /* storage method: ASIS, LZW, S2 */
    unsigned char   fn[ 9 ];                      /* null terminated */
    unsigned char   ft[ 9 ];                      /* null terminated */
    unsigned char   fm[ 3 ];                      /* null terminated */
    int             lrecl;                         /* possibly > 64k */
    int             year;
    unsigned char   month;
    unsigned char   day;
    unsigned char   hour;
    unsigned char   minute;
    unsigned char   second;
    unsigned char   recfm;
    unsigned int    ibytes;
    unsigned int    obytes;
    unsigned char   dtype;                  /* data type TRUE = text */
} SUBFILE;

/* --------------------------------------------------------------------
|| SUBFILE::dtype is only a best guess and is determined by examining
|| the first 1024 bytes of each subfile and, if any bytes fall below
|| 0x20, the mode value will be set to BINARY.
*/
#define VMAD_UNKNOWN    0
#define VMAD_TEXT       1
#define VMAD_BINARY     2

/* --------------------------------------------------------------------
|| Extraction mode
*/
#define VMAX_AUTO       0                   /* use SUBFILE:Ldtype    */
#define VMAX_TEXT       1                   /* convert to text+LF    */
#define VMAX_BINARY     2                   /* extract unchanged     */
#define VMAX_TRANS      3                   /* translate             */

/* --------------------------------------------------------------------
|| Errors
*/
enum
{
    VMAE_NOERR,                             /* no error              */
    VMAE_RERR,                              /* read error            */
    VMAE_WERR,                              /* write error           */
    VMAE_OOVER,                             /* output overflow       */
    VMAE_INACT,                             /* no active subfile     */
    VMAE_IOPEN,                             /* open input failed     */
    VMAE_OOPEN,                             /* open output failed    */
    VMAE_MEM,                               /* insufficient memory   */
    VMAE_TIME,                              /* set file times failed */
    VMAE_SEEK,                              /* repositioning failed  */
    VMAE_BADARG,                            /* missing parameter     */
    VMAE_NOMORE,                            /* mo more subfiles      */
    VMAE_NOTFOUND,                          /* subfile not found     */
    VMAE_NEEDMORE,                          /* expected more data    */
    VMAE_UCMOPEN,                           /* UCM open failed       */
    VMAE_UCMSBCS,                           /* only SBCS UCMs okay   */
    VMAE_SUBCHAR,                           /* invalid UCM subchar   */
    VMAE_CHARMAP,                           /* missing or bad cmap   */
    VMAE_LRECL,                             /* LRECL exceeds max     */
    VMAE_ASCII,                             /* VMARC appears ASCII   */
    VMAE_BADDATA,                           /* invalid input data    */
    VMAE_NUMERRORS                          /* number of errors      */
};

/* --------------------------------------------------------------------
|| Public functions
*/
extern int vma_open( const char *name, int size, void **vma );
extern void vma_close( void *vma );
extern int vma_first( void *vma, SUBFILE **sf );
extern int vma_next( void *vma, SUBFILE **sf );
extern int vma_setactive( void *vma, SUBFILE *sf );
extern int vma_extract( void *vma, const char *name, int ascii );
extern int vma_setconv( void *vma, const char *fucm, const char *tucm );
extern const char *vma_strerror( int ec );

#ifdef __cplusplus
}
#endif

#endif
