#if !defined( _VERSION_H )
#define _VERSION_H
#define VERSION "06.122a"
#define FILEVER 06,122,0,1
#define PRODVER 06,122,0,1
#define STRFILEVER "06.122a\0"
#define STRPRODVER "06.122a\0"
#endif
