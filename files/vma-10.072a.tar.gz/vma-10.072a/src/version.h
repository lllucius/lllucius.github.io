#if !defined( _VERSION_H )
#define _VERSION_H
#define LIBVER  "10.072a"
#define VERSION wxT( "10.072a" )
#define FILEVER 10,072,0,1
#define PRODVER 10,072,0,1
#define STRFILEVER "10.072a\0"
#define STRPRODVER "10.072a\0"
#endif
