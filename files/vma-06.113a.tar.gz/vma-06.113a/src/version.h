#if !defined( _VERSION_H )
#define _VERSION_H
#define VERSION "06.113a"
#define FILEVER 06,113,0,1
#define PRODVER 06,113,0,1
#define STRFILEVER "06.113a\0"
#define STRPRODVER "06.113a\0"
#endif
