#if !defined( _VERSION_H )
#define _VERSION_H
#define LIBVER  "10.070a"
#define VERSION wxT( "10.070a" )
#define FILEVER 10,070,0,1
#define PRODVER 10,070,0,1
#define STRFILEVER "10.070a\0"
#define STRPRODVER "10.070a\0"
#endif
