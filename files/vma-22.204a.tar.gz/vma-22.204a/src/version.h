#if !defined( _VERSION_H )
#define _VERSION_H
#define LIBVER  "22.204a"
#define VERSION wxT( "22.204a" )
#define FILEVER 22,204,0,1
#define PRODVER 22,204,0,1
#define STRFILEVER "22.204a\0"
#define STRPRODVER "22.204a\0"
#endif
