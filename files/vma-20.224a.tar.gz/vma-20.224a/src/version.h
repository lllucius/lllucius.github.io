#if !defined( _VERSION_H )
#define _VERSION_H
#define LIBVER  "20.224a"
#define VERSION wxT( "20.224a" )
#define FILEVER 20,224,0,1
#define PRODVER 20,224,0,1
#define STRFILEVER "20.224a\0"
#define STRPRODVER "20.224a\0"
#endif
