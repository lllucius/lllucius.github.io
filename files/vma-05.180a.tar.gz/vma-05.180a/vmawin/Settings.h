#pragma once
#include "afxwin.h"

#include "CBrowseCtrl_Src\BrowseCtrl.h"

// CSettings dialog

class CSettings : public CDialog
{
	DECLARE_DYNAMIC(CSettings)

public:
	CSettings(CWnd* pParent = NULL);   // standard constructor
	virtual ~CSettings();

// Dialog Data
	enum { IDD = IDD_SETTINGS };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
	CBrowseCtrl m_ViewTxt;
	CBrowseCtrl m_ViewBin;
	CBrowseCtrl m_UCMFrom;
	CBrowseCtrl m_UCMTo;
	CButton m_Stats;
	CEdit m_Exts;
	CComboBox m_Action;

	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedUpdate();
	afx_msg void OnBnClickedRemove();
};
