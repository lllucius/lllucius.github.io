// Settings.cpp : implementation file
//

#include "stdafx.h"
#include "vmawin.h"
#include "Settings.h"

#include "CBrowseCtrl_Src\BrowseCtrl.h"

// CSettings dialog

IMPLEMENT_DYNAMIC(CSettings, CDialog)
CSettings::CSettings(CWnd* pParent /*=NULL*/)
	: CDialog(CSettings::IDD, pParent)
{
	EnableActiveAccessibility();
}

CSettings::~CSettings()
{
}

void CSettings::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_VIEWBIN, m_ViewBin);
	DDX_Control(pDX, IDC_VIEWTXT, m_ViewTxt);
	DDX_Control(pDX, IDC_STATS, m_Stats);
	DDX_Control(pDX, IDC_EXTS, m_Exts);
	DDX_Control(pDX, IDC_Action, m_Action);
	DDX_Control(pDX, IDC_FUCM, m_UCMFrom);
	DDX_Control(pDX, IDC_TUCM, m_UCMTo);
}


BEGIN_MESSAGE_MAP(CSettings, CDialog)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
	ON_BN_CLICKED(IDC_UPDATE, OnBnClickedUpdate)
	ON_BN_CLICKED(IDC_REMOVE, OnBnClickedRemove)
END_MESSAGE_MAP()


// CSettings message handlers

BOOL CSettings::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_ViewTxt.SetPathName( theApp.GetProfileString( _T( "Settings" ),
													_T( "Text Viewer" ),
													_T( "Notepad" ) ) );
	m_ViewTxt.SetButtonStyle( BC_CTL_ALLOWEDIT | BC_BTN_ICON | BC_ICO_EXPLORER );
	m_ViewTxt.SetFilter( "Applications (*.exe)|*.exe||" );

	m_ViewBin.SetPathName( theApp.GetProfileString( _T( "Settings" ),
													_T( "Binary Viewer" ),
													_T( "Notepad" ) ) );
	m_ViewBin.SetButtonStyle( BC_CTL_ALLOWEDIT | BC_BTN_ICON | BC_ICO_EXPLORER );
	m_ViewBin.SetFilter( "Applications (*.exe)|*.exe||" );

	m_UCMFrom.SetPathName( theApp.GetProfileString( _T( "Settings" ),
													_T( "From UCM" ),
													_T( "" ) ) );
	m_UCMFrom.SetButtonStyle( BC_CTL_ALLOWEDIT | BC_BTN_ICON | BC_ICO_EXPLORER );
	m_UCMFrom.SetFilter( "Unicode Charmap (*.ucm)|*.ucm||" );

	m_UCMTo.SetPathName( theApp.GetProfileString( _T( "Settings" ),
												  _T( "To UCM" ),
												  _T( "" ) ) );
	m_UCMTo.SetButtonStyle( BC_CTL_ALLOWEDIT | BC_BTN_ICON | BC_ICO_EXPLORER );
	m_UCMTo.SetFilter( "Unicode Charmap (*.ucm)|*.ucm||" );

	m_Exts.SetWindowText( theApp.GetProfileString( _T( "Settings" ),
												   _T( "Extentions" ),
												   _T( ".vmarc;.vma" ) ) );

	m_Stats.SetCheck( theApp.GetProfileInt( _T( "Settings" ),
											_T( "Subfile Stats" ),
											true )
											? BST_CHECKED : BST_UNCHECKED );

	m_Action.SetCurSel( theApp.GetProfileInt( _T( "Settings" ),
											  _T( "Default Action" ),
											  1 ) );



	return TRUE;
}

void CSettings::OnBnClickedOk()
{
	OnOK();

	theApp.WriteProfileString( "Settings", "Text Viewer", m_ViewTxt.GetPathName() );

	theApp.WriteProfileString( "Settings", "Binary Viewer", m_ViewBin.GetPathName() );

	theApp.WriteProfileString( "Settings", "From UCM", m_UCMFrom.GetPathName() );

	theApp.WriteProfileString( "Settings", "To UCM", m_UCMTo.GetPathName() );

	theApp.WriteProfileInt( "Settings", "Subfile Stats", m_Stats.GetCheck() );

	theApp.WriteProfileInt( "Settings", "Default Action", m_Action.GetCurSel() );
}

void CSettings::OnBnClickedUpdate()
{
	CString exts;
	CString ext;
	CString app;
	CString val;
	int len;
	int start = 0;

	len = m_Exts.GetWindowTextLength();
	if( len == 0 )
	{
		return;
	}

	::PathCanonicalize( app.GetBuffer( MAX_PATH ), __targv[ 0 ] );
	app.ReleaseBuffer();

	::SHSetValue( HKEY_CLASSES_ROOT,
				  "VMARC_Hive",
				  "",
				  REG_SZ,
				  "VMARC Hive",
				  sizeof( "VMARC Hive" ) - 1 );

	::SHSetValue( HKEY_CLASSES_ROOT,
				  "VMARC_Hive\\shell",
				  "",
				  REG_SZ,
				  "open",
				  sizeof( "open" ) - 1 );

	::SHSetValue( HKEY_CLASSES_ROOT,
				  "VMARC_Hive\\shell\\open",
				  "",
				  REG_SZ,
				  "Open",
				  sizeof( "Open" ) - 1 );

	val = app + " \"%1\"";
	::SHRegSetPath( HKEY_CLASSES_ROOT,
					"VMARC_Hive\\shell\\open\\command",
					"",
					val.GetBuffer(),
					0 );
	val.ReleaseBuffer();

	::SHSetValue( HKEY_CLASSES_ROOT,
				  "VMARC_Hive\\shell\\extract",
				  "",
				  REG_SZ,
				  "Extract to...",
				  sizeof( "Extract to..." ) - 1 );
 
	val = app + " /x \"%1\"";
	::SHRegSetPath( HKEY_CLASSES_ROOT,
					"VMARC_Hive\\shell\\extract\\command",
					"",
					val.GetBuffer(),
					0 );
	val.ReleaseBuffer();

	val = app + ",0";
	::SHRegSetPath( HKEY_CLASSES_ROOT,
					"VMARC_Hive\\DefaultIcon",
					"",
					val.GetBuffer(),
					0 );
	val.ReleaseBuffer();

	m_Exts.GetWindowText( exts.GetBuffer( len + 1 ), len + 1 );
	exts.ReleaseBuffer();

	len = 0;
	while( start != -1 )
	{
		ext = exts.Tokenize( ";", start ).Trim();
		if( ext.GetLength() == 0 )
		{
			continue;
		}

		if( ext[ 0 ] != '.' )
		{
			ext = '.' + ext;
		}

		::SHSetValue( HKEY_CLASSES_ROOT,
					  ext.GetBuffer(),
					  "",
					  REG_SZ,
					  "VMARC_Hive",
					  sizeof( "VMARC_Hive" ) - 1 );
		ext.ReleaseBuffer();

		len++;
	}

	::SHChangeNotify( SHCNE_ASSOCCHANGED, SHCNF_IDLIST, 0, 0 );

	theApp.WriteProfileString( "Settings", "Extensions", exts );

	exts.Format( "%d extensions registered", len );
	MessageBox( exts, "Helpful Message" );

	return;
}

void CSettings::OnBnClickedRemove()
{
	CString exts;
	CString ext;
	CString val;
	DWORD len;
	DWORD type;
	int start = 0;

	::SHDeleteKey( HKEY_CLASSES_ROOT,
				   "VMARC_Hive" );

	exts = theApp.GetProfileString( _T( "Settings" ),
									_T( "Extentions" ),
									_T( ".vmarc" ) );
	exts.Trim();

	if( exts.GetLength() == 0 )
	{
		return;
	}

	while( start != -1 )
	{
		ext = exts.Tokenize( ";", start ).Trim();
		if( ext.GetLength() == 0 )
		{
			continue;
		}

		if( ext[ 0 ] != '.' )
		{
			ext = '.' + ext;
		}

		type = REG_SZ;
		::SHGetValue( HKEY_CLASSES_ROOT,
					  ext.GetBuffer(),
					  "",
					  &type,
					  val.GetBuffer( 32 ),
					  &len );
		ext.ReleaseBuffer();
		val.ReleaseBuffer();

		if( val != "VMARC_Hive" )
		{
			continue;
		}

		::SHDeleteKey( HKEY_CLASSES_ROOT,
					   ext.GetBuffer() );
		ext.ReleaseBuffer();
	}

	::SHChangeNotify( SHCNE_ASSOCCHANGED, SHCNF_IDLIST, 0, 0 );

	m_Exts.SetWindowText( "" );
	theApp.WriteProfileString( "Settings", "Extensions", "" );

	exts.Format( "All extensions removed.\n"
				 "You must click 'Update' to re-associate.",
				 len );
	MessageBox( exts, "Helpful Message" );

	return;
}
