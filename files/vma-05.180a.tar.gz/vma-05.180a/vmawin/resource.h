//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by vmawin.rc
//
#define IDC_EXTALL                      3
#define IDC_UPDATE                      3
#define IDC_REMOVE                      4
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDS_ABOUTBOX                    101
#define IDD_VMAWIN_DIALOG               102
#define IDSTATUS                        103
#define IDC_STATUS                      103
#define IDR_MAINFRAME                   128
#define IDD_SETTINGS                    132
#define IDR_ACCELERATOR1                133
#define IDI_ICON1                       137
#define IDI_ICON2                       138
#define IDC_LIST                        1000
#define IDC_VIEW                        1001
#define IDC_EXTRACT                     1015
#define IDC_OPEN                        1016
#define IDC_PATTERN                     1017
#define IDC_LABPAT                      1018
#define IDC_SETTINGS                    1019
#define IDC_VIEWBIN                     1020
#define IDC_VIEWTXT                     1021
#define IDC_FUCM                        1022
#define IDC_VIEWBIN2                    1023
#define IDC_TUCM                        1023
#define IDC_STATS                       1029
#define IDC_EDIT1                       1030
#define IDC_EXTS                        1030
#define IDC_COMBO1                      1032
#define IDC_Action                      1032
#define IDC_BUTTON2                     1034
#define IDC_BUTTON3                     1035
#define IDC_AUTO                        2000
#define IDC_TEXT                        2001
#define IDC_BINARY                      2002
#define IDA_CTRL_A                      32771
#define IDA_ENTER                       32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
