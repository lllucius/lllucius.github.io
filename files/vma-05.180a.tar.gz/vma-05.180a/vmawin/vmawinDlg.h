// vmawinDlg.h : header file
//

#pragma once

#include "afxcmn.h"
#include "vma.h"

#include "ListViewCtrlEx/ListViewCtrlEx.h"
#include "easysize_src/EasySize.h"
#include "afxwin.h"

#define EASYSIZE_EXCLUDE_ERASEBKGND(ID)\
{CRect rect; this->GetDlgItem(ID)->GetWindowRect(&rect);\
ScreenToClient(rect); pDC->ExcludeClipRect(rect);}

// CvmawinDlg dialog
class CvmawinDlg : public CDialog
{
// Construction
public:
	CvmawinDlg(CWnd* pParent = NULL );

// Dialog Data
	enum { IDD = IDD_VMAWIN_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	enum Format
	{
		FmtAuto = 0,
		FmtText,
		FmtBinary
	};

	enum Field
	{
		Fn = 0,
		Ft,
		Fm,
		Date,
		Recfm,
		Lrecl,
		Ibytes,
		Obytes,
		Verrel,
		Method,
		Dtype
	};

	void LoadSettings( void );
	void SaveSettings( void );
	bool OpenArchive( char *name /* = NULL */ );
	CString Format( SUBFILE *sf, int nField );
	CString OutputName( SUBFILE *sf );
	bool Extract( SUBFILE *sf, CString dest, int nItem );

	static int CALLBACK Compare( LPARAM lParam1,
								 LPARAM lParam2,
								 LPARAM lParamSort );

	HICON m_hIcon;
	void *m_vma;
	CString m_Filename;
	CString m_OpenPath;
	CString m_SavePath;
	CString m_UCMFrom;
	CString m_UCMTo;
	CListCtrlEx m_List;
	CButton m_Auto;
	CButton m_Text;
	CButton m_Binary;
	CStatic m_Status;
	CEdit m_Pattern;
	CString m_TxtViewer;
	CString m_BinViewer;
	CString m_Filter;
	UINT m_Stats;
	UINT m_Format;
	UINT m_Action;

	HACCEL m_hAccel;

	CString msg;
 
	SUBFILE *m_sf;
	Field m_sortby;

	DECLARE_EASYSIZE;

	// Generated message map functions
	//{{AFX_MSG(CvmawinDlg)
	BOOL CvmawinDlg::PreTranslateMessage( MSG* pMsg );
	virtual void OnCancel( void );
	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSizing(UINT fwSide, LPRECT pRect);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnLvnColumnclickList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedExtract();
	afx_msg void OnBnClickedExtAll();
	afx_msg void OnBnClickedSettings();
	afx_msg void OnBnClickedOpen();
	afx_msg void OnBnClickedAuto();
	afx_msg void OnBnClickedText();
	afx_msg void OnBnClickedBinary();
	afx_msg void OnEnKillfocusPattern();
	afx_msg void OnBnClickedView();
	afx_msg void OnNMDblclkList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnCtrlA();
	afx_msg void OnEnter();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
