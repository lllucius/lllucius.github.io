// vmawinDlg.cpp : implementation file
//

#include "stdafx.h"

#include <time.h>

#include "vmawin.h"
#include "vmawinDlg.h"
#include "settings.h"

#include "vma.h"

#include "CBrowseCtrl_Src\BrowseCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	EnableActiveAccessibility();
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CvmawinDlg dialog

// ====================================================================
// Compare function for column sorting
// ====================================================================
int CALLBACK
CvmawinDlg::Compare( LPARAM lParam1,
					 LPARAM lParam2, 
                     LPARAM lParamSort )
{
	SUBFILE *sf1 = reinterpret_cast<SUBFILE *>(lParam1);
	SUBFILE *sf2 = reinterpret_cast<SUBFILE *>(lParam2);
	bool    bComplementResult = false;
	int     result = 0;

	if( lParamSort < 0)
	{
		lParamSort = ~lParamSort;
		bComplementResult = true;
	}
	else
	{
		lParamSort--;
	}

	switch( lParamSort )
	{
		case Fn:
			result = lstrcmpi( (char *)sf1->fn, (char *)sf2->fn );
		break;

		case Ft:
			result = lstrcmpi( (char *)sf1->ft, (char *)sf2->ft );
		break;

		case Fm:
			result = lstrcmpi( (char *)sf1->fm, (char *)sf2->fm );
		break;

		case Date:
			{
				struct tm bt;
				time_t ct1;
				time_t ct2;

				/*
				|| 
				*/
				bt.tm_sec = sf1->second;
				bt.tm_min = sf1->minute;
				bt.tm_hour = sf1->hour;
				bt.tm_mday = sf1->day;
				bt.tm_mon = sf1->month;
				bt.tm_year = sf1->year - 1900;
				bt.tm_wday = 0;
				bt.tm_yday = 0;
				bt.tm_isdst = 0;
		    
				ct1 = mktime( &bt );
				/*
				|| 
				*/
				bt.tm_sec = sf2->second;
				bt.tm_min = sf2->minute;
				bt.tm_hour = sf2->hour;
				bt.tm_mday = sf2->day;
				bt.tm_mon = sf2->month;
				bt.tm_year = sf2->year - 1900;
				bt.tm_wday = 0;
				bt.tm_yday = 0;
				bt.tm_isdst = 0;
		    
				ct2 = mktime( &bt );

				result = static_cast<int>(ct1 - ct2);
		}
		break;

		case Recfm:
			result = sf1->recfm - sf2->recfm;
		break;

		case Lrecl:
			result = sf1->lrecl - sf2->lrecl;
		break;

		case Ibytes:
			result = sf1->ibytes - sf2->ibytes;
		break;

		case Obytes:
			result = sf1->obytes - sf2->obytes;
		break;

		case Verrel:
			result =  ( ( sf1->ver << 8 ) + sf1->rel ) -
				      ( ( sf2->ver << 8 ) + sf2->rel );
		break;

		case Method:
			result = lstrcmpi( (char *)sf1->meth, (char *)sf2->meth );
		break;

		case Dtype:
			result = lstrcmpi( (char *)sf1->meth, (char *)sf2->meth );
		break;
	}

	return bComplementResult ? -result : result;
}

CString
CvmawinDlg::Format( SUBFILE *sf, int nField )
{
	CString szResult;

	switch( nField )
	{
		case Fn:
			szResult = sf->fn;
		break;

		case Ft:
			szResult = sf->ft;
		break;

		case Fm:
			szResult = sf->fm;
		break;

		case Date:
			szResult.Format( "%04d/%02d/%02d %02d:%02d:%02d",
							 sf->year,
							 sf->month,
							 sf->day,
							 sf->hour,
							 sf->minute,
							 sf->second );
		break;

		case Recfm:
			szResult.Format( "%c", sf->recfm );
		break;

		case Lrecl:
			szResult.Format( "%d", sf->lrecl );
		break;

		case Ibytes:
			szResult.Format( "%d", sf->ibytes );
		break;

		case Obytes:
			szResult.Format( "%d", sf->obytes );
		break;

		case Verrel:
			szResult.Format( "%d.%d", sf->ver, sf->rel );
		break;

		case Method:
			szResult = sf->meth;
		break;

		case Dtype:
			switch( sf->dtype )
			{
				case VMAD_UNKNOWN:
					szResult = "Unknown";
				break;

				case VMAD_TEXT:
					szResult = "Text";
				break;

				case VMAD_BINARY:
					szResult = "Binary";
				break;
			}
		break;
	}

	return szResult;
}

CString CvmawinDlg::OutputName( SUBFILE *sf )
{
	CString pat;
	CString name;
	CString temp;
	char *p;

	m_Pattern.GetWindowText( pat );

	p = pat.GetBuffer();
	while( *p )
	{
		if( *p == '%' )
		{
			p++;
			switch( *p )
			{
				case '\0':
					name += '%';
				break;

				case 'n':
					temp = (char *)sf->fn;
					temp.MakeLower();
					name += temp;
				break;

				case 'N':
					temp = (char *)sf->fn;
					temp.MakeUpper();
					name += temp;
				break;

				case 't':
					temp = (char *)sf->ft;
					temp.MakeLower();
					name += temp;
				break;

				case 'T':
					temp = (char *)sf->ft;
					temp.MakeUpper();
					name += temp;
				break;

				case 'm':
					temp = (char *)sf->fm;
					temp.MakeLower();
					name += temp;
				break;

				case 'M':
					temp = (char *)sf->fm;
					temp.MakeUpper();
					name += temp;
				break;

				default:
					name += '%';
					name += *p;
				break;
			}
		}
		else
		{
			name += *p;
		}

		p++;
	}
	pat.ReleaseBuffer();
	
	return name;
}
		
bool CvmawinDlg::Extract( SUBFILE *sf, CString dest, int nItem )
{
	int mode;
	int rc;

	// Determine the extraction mode
	mode = VMAX_AUTO;
	switch( GetCheckedRadioButton( IDC_AUTO, IDC_BINARY ) )
	{
		case IDC_TEXT:
			mode = VMAX_TEXT;
		break;

		case IDC_BINARY:
			mode = VMAX_BINARY;
		break;
	}

	// Users don't like sitting in the dark
	msg.Format( " Extracting %s.%s.%s",
				sf->fn,
				sf->ft,
				sf->fm );
	m_Status.SetWindowText( msg );

	// Make this the active subfile
	vma_setactive( m_vma, sf );

	// Extract it
	rc = vma_extract( m_vma, dest.GetBuffer(), mode );
	dest.ReleaseBuffer();

	// Complain if there was an error
	if( rc != VMAE_NOERR )
	{
		msg.Format( " Extraction of %s.%s.%s failed with %d",
					sf->fn,
					sf->ft,
					sf->fm,
					rc );
		MessageBox( msg, "Not So Helpful Message" );
		m_Status.SetWindowText( msg );

		return false;
	}

	// Refresh stats for this entry since they are now available
	m_List.SetItemText( nItem, Ibytes, Format( sf, Ibytes ) );
	m_List.SetItemText( nItem, Obytes, Format( sf, Obytes ) );
	m_List.SetItemText( nItem, Dtype,  Format( sf, Dtype  ) );
	
	// Unselect the list item
	m_List.SetItemState( nItem, 0, LVIS_SELECTED );

	// A silly little message
	msg.Format( " %s.%s.%s extracted",
					sf->fn,
					sf->ft,
					sf->fm );
	m_Status.SetWindowText( msg );

	return true;
}

bool CvmawinDlg::OpenArchive( char *name = NULL )
{
	SUBFILE *sf;
	int rc;

	// Ask user for filename if one wasn't specified
	if( name == NULL )
	{
		CBrowseCtrl fd;

		if( !m_Filter.IsEmpty() )
		{
			fd.SetFilter( m_Filter + "All Files|*.*||" );
		}

		fd.SetInitialDir( m_OpenPath );
		if( fd.DoModal() != IDOK )
		{
			return false;
		}

		m_Filename = fd.GetPathName();
	}
	else
	{
		::PathCanonicalize( m_Filename.GetBuffer( MAX_PATH ), name );
		m_Filename.ReleaseBuffer();
	}

	// 
	m_OpenPath = m_Filename;
	::PathRemoveFileSpec( m_OpenPath.GetBuffer( MAX_PATH ) );
	m_OpenPath.ReleaseBuffer();

	// Close previous archive (if any)
	if( m_vma )
	{
		vma_close( m_vma );
		m_vma = NULL;
	}

	// Get rid of any previous list items
	m_List.DeleteAllItems();

	// Keep this as a separate block for the CWaitCursor
	{
		CWaitCursor wait;

		// Open the new archive
		rc = vma_open( m_Filename.GetBuffer(), m_Stats, &m_vma );
		m_Filename.ReleaseBuffer();
		if( rc != VMAE_NOERR )
		{
			msg.Format( "Open failed - rc: %d\n", rc );
			MessageBox( msg, "Not So Helpful Message" );
			return false;
		}

		// Set the conversion tables
		if( !m_UCMFrom.IsEmpty() && !m_UCMTo.IsEmpty() )
		{
			rc = vma_setconv( m_vma,
							  m_UCMFrom.GetBuffer(),
							  m_UCMTo.GetBuffer() );
			m_UCMFrom.ReleaseBuffer();
			m_UCMTo.ReleaseBuffer();

			if( rc != VMAE_NOERR )
			{
				msg.Format( "Conversion table load failed: %d\n", rc );
				MessageBox( msg, "Not So Helpful Message" );
				vma_close( m_vma );
				m_vma = NULL;
				return false;
			}
		}
		else
		{
			vma_setconv( m_vma, NULL, NULL );
		}

		// Add each subfile to the list
		for( rc = vma_first( m_vma, &sf );
			rc == VMAE_NOERR;
			rc = vma_next( m_vma, &sf ) )
		{
			int nIndex;

			nIndex = m_List.InsertItem( m_List.GetItemCount(), (char *)sf->fn );
			if( nIndex >= 0 )
			{
				m_List.SetItemData( nIndex, (DWORD_PTR) sf );

				m_List.SetItemText( nIndex, Ft,     Format( sf, Ft     ) );
				m_List.SetItemText( nIndex, Fm,     Format( sf, Fm     ) );
				m_List.SetItemText( nIndex, Date,   Format( sf, Date   ) );
				m_List.SetItemText( nIndex, Recfm,  Format( sf, Recfm  ) );
				m_List.SetItemText( nIndex, Lrecl,  Format( sf, Lrecl  ) );
				m_List.SetItemText( nIndex, Ibytes, Format( sf, Ibytes ) );
				m_List.SetItemText( nIndex, Obytes, Format( sf, Obytes ) );
				m_List.SetItemText( nIndex, Verrel, Format( sf, Verrel ) );
				m_List.SetItemText( nIndex, Method, Format( sf, Method ) );
				m_List.SetItemText( nIndex, Dtype,  Format( sf, Dtype  ) );
			}
		}

		m_List.SortItems( Compare, m_sortby );
		m_List.AutoSizeColumns( -1 );
	};

	// Finally, set the window title
	msg.Format( "VMAWin - %s", m_Filename );
	SetWindowText( msg );
		
	return true;
}

// ====================================================================
// Save profile settings
// ====================================================================
void CvmawinDlg::SaveSettings( void )
{
	WINDOWPLACEMENT wp;
	CString str;

    GetWindowPlacement( &wp );
	theApp.WriteProfileBinary( "Settings",
							   "Window",
							   (LPBYTE)&wp,
							   sizeof( wp ) );

	theApp.WriteProfileString( "Settings",
							   "Open Path",
							   m_OpenPath );

	theApp.WriteProfileString( "Settings",
							   "Save Path",
							   m_SavePath );

	theApp.WriteProfileInt( "Settings",
							"Format",
							m_Format );

	m_Pattern.GetWindowText( str );
	theApp.WriteProfileString( "Settings",
							   "Pattern",
							   str );

}

// ====================================================================
// Load profile settings
// ====================================================================
void CvmawinDlg::LoadSettings( void )
{
	CString str;
	CString exts;
	CString ext;
	int firstime;
	int start;

	firstime = theApp.GetProfileInt( _T( "Settings" ),
									 _T( "First Time" ),
									 1 );
	if( firstime )
	{
		MessageBox( "You may want to use the Settings dialog to select the file\n"
					"extensions you'd like to have associated with VMAWin.",
					"Welcome to VMAWin" );

		theApp.WriteProfileInt( "Settings",
								"First Time",
								0 );
	}

	m_Format = theApp.GetProfileInt( _T( "Settings" ),
									 _T( "Format" ),
									 0 );

	str = theApp.GetProfileString( _T( "Settings" ),
								   _T( "Pattern" ),
								   _T( "%n.%t.%m" ) );
	m_Pattern.SetWindowText( str );

	m_OpenPath = theApp.GetProfileString( _T( "Settings" ),
										  _T( "Open Path" ),
										  _T( "c:\\" ) );

	m_SavePath = theApp.GetProfileString( _T( "Settings" ),
										  _T( "Save Path" ),
										  _T( "c:\\" ) );

	m_Stats = theApp.GetProfileInt( _T( "Settings" ),
									_T( "Subfile Stats" ),
									true );

	m_TxtViewer = theApp.GetProfileString( _T( "Settings" ),
										   _T( "Text Viewer" ),
										   _T( "Notepad" ) );

	m_BinViewer = theApp.GetProfileString( _T( "Settings" ),
										   _T( "Binary Viewer" ),
										   _T( "Notepad" ) );

	m_UCMFrom = theApp.GetProfileString( _T( "Settings" ),
										 _T( "From UCM" ),
										 _T( "" ) );

	m_UCMTo = theApp.GetProfileString( _T( "Settings" ),
									   _T( "To UCM" ),
									   _T( "" ) );


	exts = theApp.GetProfileString( _T( "Settings" ),
									_T( "Extensions" ),
									_T( ".vma;.vmarc" ) );

	start = 0;
	m_Filter.Empty();
	while( start != -1 )
	{
		ext = exts.Tokenize( ";", start ).Trim();
		if( ext.GetLength() == 0 )
		{
			continue;
		}

		if( ext[ 0 ] != '.' )
		{
			ext = '.' + ext;
		}

		if( ext[ 0 ] != '*' )
		{
			ext = '*' + ext;
		}

		m_Filter += ext + ';';
	}

	if( !m_Filter.IsEmpty() )
	{
		m_Filter = "VMARC Hives|" + m_Filter + '|';
	}

	return;
}

// ====================================================================
// Standard constructor
// ====================================================================
CvmawinDlg::CvmawinDlg( CWnd* pParent /*=NULL*/ )
	: CDialog( CvmawinDlg::IDD, pParent )
{
	// Everyone should do this
	EnableActiveAccessibility();

	// Get a handle to our cute little teddy
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	// Misc initialization
	m_vma = NULL;
	m_sortby = Fm;
}

// ====================================================================
// Retrieve control pointers
// ====================================================================
void CvmawinDlg::DoDataExchange( CDataExchange* pDX )
{
	CDialog::DoDataExchange( pDX );

	DDX_Control( pDX, IDC_LIST,		m_List );
	DDX_Control( pDX, IDC_STATUS,	m_Status );
	DDX_Control( pDX, IDC_AUTO,		m_Auto );
	DDX_Control( pDX, IDC_TEXT,		m_Text );
	DDX_Control( pDX, IDC_BINARY,	m_Binary );
	DDX_Control( pDX, IDC_PATTERN,  m_Pattern );
}

// ====================================================================
// Message map
// ====================================================================
BEGIN_MESSAGE_MAP( CvmawinDlg, CDialog )
	//{{AFX_MSG_MAP(CvmawinDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
    ON_WM_SIZE()
	ON_WM_SIZING()
	ON_WM_ERASEBKGND()
	ON_BN_CLICKED( IDC_EXTRACT, OnBnClickedExtract )
	ON_BN_CLICKED( IDC_EXTALL, OnBnClickedExtAll )
	ON_NOTIFY( LVN_COLUMNCLICK, IDC_LIST, OnLvnColumnclickList )
	ON_BN_CLICKED(IDC_SETTINGS, OnBnClickedSettings)
	ON_BN_CLICKED(IDC_OPEN, OnBnClickedOpen)
	ON_BN_CLICKED(IDC_AUTO, OnBnClickedAuto)
	ON_BN_CLICKED(IDC_TEXT, OnBnClickedText)
	ON_BN_CLICKED(IDC_BINARY, OnBnClickedBinary)
	ON_EN_KILLFOCUS(IDC_PATTERN, OnEnKillfocusPattern)
	ON_BN_CLICKED(IDC_VIEW, OnBnClickedView)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST, OnNMDblclkList)
	ON_COMMAND(IDA_CTRL_A, OnCtrlA)
	ON_COMMAND(IDA_ENTER, OnEnter)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// ====================================================================
// Dialog layout map
// ====================================================================
BEGIN_EASYSIZE_MAP(CvmawinDlg)
//  EASYSIZE( control, left, top, right, bottom, options )
	EASYSIZE( IDC_EXTRACT, ES_BORDER, ES_BORDER, ES_KEEPSIZE, ES_KEEPSIZE, 0 )

	EASYSIZE( IDC_BINARY, ES_KEEPSIZE, ES_BORDER, ES_BORDER, ES_KEEPSIZE, 0 )
	EASYSIZE( IDC_TEXT, ES_KEEPSIZE, ES_BORDER, IDC_BINARY, ES_KEEPSIZE, 0 )
	EASYSIZE( IDC_AUTO, ES_KEEPSIZE, ES_BORDER, IDC_TEXT, ES_KEEPSIZE, 0 )
	EASYSIZE( IDC_PATTERN, ES_KEEPSIZE, ES_BORDER, IDC_AUTO, ES_KEEPSIZE, 0 )
	EASYSIZE( IDC_LABPAT, ES_KEEPSIZE, ES_BORDER, IDC_PATTERN, ES_KEEPSIZE, 0 )

	EASYSIZE( IDC_STATUS, ES_BORDER, ES_KEEPSIZE, ES_BORDER, ES_BORDER, 0 )
	EASYSIZE( IDC_LIST, ES_BORDER, IDC_EXTRACT, ES_BORDER, IDC_STATUS, 0 )
END_EASYSIZE_MAP

/* ********************************************************************
|| Overrides                                                         ||
******************************************************************** */

// ====================================================================
// Handle accelerator keys
// ====================================================================
BOOL CvmawinDlg::PreTranslateMessage( MSG* pMsg )
{
	if( WM_KEYFIRST <= pMsg->message && pMsg->message <= WM_KEYLAST )
	{
		if( m_hAccel && ::TranslateAccelerator( m_hWnd, m_hAccel, pMsg ) )
		{
			return TRUE;
		}
	}

	return CDialog::PreTranslateMessage( pMsg );
}

// ====================================================================
// We always leave the dialog through OnCancel()
// ====================================================================
void CvmawinDlg::OnCancel( void )
{
	// Close any open VMARCs
	if( m_vma )
	{
		vma_close( m_vma );
		m_vma = NULL;
	}

	// Save our profile settings
	SaveSettings();

	// Invoke standard method
	CDialog::OnCancel();
}

// ====================================================================
// Initialize our world
// ====================================================================
BOOL CvmawinDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Load profile settings
	LoadSettings();

	// Load the accelerators
	m_hAccel = ::LoadAccelerators( AfxGetResourceHandle(),
								   MAKEINTRESOURCE( IDR_ACCELERATOR1 ) );

	// Add "About..." menu item to system menu.
	{
		// IDM_ABOUTBOX must be in the system command range.
		ASSERT( ( IDM_ABOUTBOX & 0xFFF0 ) == IDM_ABOUTBOX );
		ASSERT( IDM_ABOUTBOX < 0xF000 );

		CMenu *pSysMenu = GetSystemMenu( FALSE );
		if( pSysMenu != NULL )
		{
			CString strAboutMenu;

			strAboutMenu.LoadString( IDS_ABOUTBOX );
			if( !strAboutMenu.IsEmpty() )
			{
				pSysMenu->AppendMenu( MF_SEPARATOR);
				pSysMenu->AppendMenu( MF_STRING, IDM_ABOUTBOX, strAboutMenu );
			}
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon( m_hIcon, TRUE );			// Set big icon
	SetIcon( m_hIcon, FALSE );			// Set small icon

	// Get/set the output format
	switch( m_Format )
	{
		default:
			m_Auto.SetCheck( BST_CHECKED );
		break;

		case FmtText:
			m_Text.SetCheck( BST_CHECKED );
		break;

		case FmtBinary:
			m_Binary.SetCheck( BST_CHECKED );
		break;
	}

	// Setup the list
	m_List.SetExtendedStyle( LVS_EX_FULLROWSELECT |
							 LVS_EX_HEADERDRAGDROP |
							 LVS_EX_LABELTIP );

	m_List.InsertColumn( Fn,     "Fn",        LVCFMT_LEFT  );
	m_List.InsertColumn( Ft,     "Ft",        LVCFMT_LEFT  );
	m_List.InsertColumn( Fm,     "Fm",        LVCFMT_LEFT  );
	m_List.InsertColumn( Date,   "Date",      LVCFMT_LEFT  );
	m_List.InsertColumn( Recfm,  "Recfm",     LVCFMT_LEFT  );
	m_List.InsertColumn( Lrecl,  "Lrecl",     LVCFMT_RIGHT );
	m_List.InsertColumn( Ibytes, "Bytes in",  LVCFMT_RIGHT );
	m_List.InsertColumn( Obytes, "Bytes out", LVCFMT_RIGHT );
	m_List.InsertColumn( Verrel, "V.R",       LVCFMT_LEFT  );
	m_List.InsertColumn( Method, "Method",    LVCFMT_LEFT  );
	m_List.InsertColumn( Dtype,  "Type",      LVCFMT_LEFT  );

	m_List.SetSortColumn( 0 );

	// Process command line arguments
	if( __argc == 2 )
	{
		OpenArchive( __argv[ 1 ] );
	}
	else if( __argc == 3 )
	{
		if( strcmp( __argv[ 1 ], "/x" ) == 0 )
		{
			if( OpenArchive( __argv[ 2 ] ) )
			{
				OnBnClickedExtAll();
			}

			m_Status.GetWindowText( msg );
			if( !msg.IsEmpty() )
			{
				MessageBox( msg, "Helpful Message" );
			}

			EndDialog( 0 );

			return FALSE;
		}
	}

	// Resize columns based on new contents
	m_List.AutoSizeColumns( -1 );

	// Reposition controls
	INIT_EASYSIZE;

	// Restore saved window info...must be done after INIT_EASYSIZE!
	{
		WINDOWPLACEMENT *wp;
        UINT nl;

        if( theApp.GetProfileBinary( "Settings", "Window", (LPBYTE*) &wp, &nl ) )
        {
            SetWindowPlacement( wp );
            delete [] wp;
        }
    }

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// ====================================================================
// Display out nifty little About dialog
// ====================================================================
void CvmawinDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if( ( nID & 0xFFF0 ) == IDM_ABOUTBOX )
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.
void CvmawinDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CvmawinDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

// ====================================================================
// Prevent flickering of controls (doesn't work for List control) 
// ====================================================================
BOOL CvmawinDlg::OnEraseBkgnd(CDC* pDC)
{
	EASYSIZE_EXCLUDE_ERASEBKGND( IDC_EXTRACT );
	EASYSIZE_EXCLUDE_ERASEBKGND( IDC_EXTALL );
	EASYSIZE_EXCLUDE_ERASEBKGND( IDC_VIEW );
	EASYSIZE_EXCLUDE_ERASEBKGND( IDC_LIST );

	EASYSIZE_EXCLUDE_ERASEBKGND( IDC_AUTO );
	EASYSIZE_EXCLUDE_ERASEBKGND( IDC_TEXT );
	EASYSIZE_EXCLUDE_ERASEBKGND( IDC_BINARY );

	return CDialog::OnEraseBkgnd( pDC );
}

// ====================================================================
// EasySize must be invoked during sizing events
// ====================================================================
void CvmawinDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);

	UPDATE_EASYSIZE;
}

// ====================================================================
// Don't allow the window to go below a given size
// ====================================================================
void CvmawinDlg::OnSizing(UINT fwSide, LPRECT pRect) 
{
    CDialog::OnSizing(fwSide, pRect);

	EASYSIZE_MINSIZE( 685, 250, fwSide, pRect );
}

// ====================================================================
// Handle the Open button
// ====================================================================
void CvmawinDlg::OnBnClickedOpen()
{
	OpenArchive();

	return;
}

// ====================================================================
// Handle the Extract button
// ====================================================================
void CvmawinDlg::OnBnClickedExtract()
{
	POSITION pos;
	SUBFILE *sf;
	CString dest;
	int nItem;
	int cnt = m_List.GetSelectedCount();

	// Can't do anything without selections
	if( cnt == 0 )
	{
		MessageBox( "I'm just thinkin' here, but maybe, just maybe, selecting something might work a little better?", "Helpful Message" );

		return;
	}

	// Only one file selected...handle it
	if( cnt == 1 )
	{
		// Position to the first (only) selected item
		pos = m_List.GetFirstSelectedItemPosition();

		// Retrieve its item number
		nItem = m_List.GetNextSelectedItem( pos );

		// And the SUBFILE ptr
		sf = (SUBFILE *) m_List.GetItemData( nItem );

		// Generate an output name and append to previous folder path
		dest = m_SavePath;
		::PathAppend( dest.GetBuffer( MAX_PATH ),
					  OutputName( sf ) );
		dest.ReleaseBuffer();

		// Create a Save dialog
		CBrowseCtrl fd;

		fd.SetOpenSave( FALSE );
		fd.SetPathName( dest );
		if( fd.DoModal() != IDOK )
		{
			return;
		}

		// Retrieve the (possibly updated) file name
		dest = fd.GetPathName();

		// Remember the folder part
		m_SavePath = dest;
		::PathRemoveFileSpec( m_SavePath.GetBuffer() );
		m_SavePath.ReleaseBuffer();

		// Extract it
		Extract( sf, dest, nItem );

		return;
	}

	// Create the "Browse for Folder" dialog
	CBrowseCtrl dlg;

	dlg.SetPathName( m_SavePath );
	dlg.SetButtonStyle( BC_CTL_FOLDERSONLY );

	// And display it
	if( dlg.DoModal() != IDOK )
	{
		return;
	}

	// Remember the path
	m_SavePath = dlg.GetDirectory();

	// Position to first selected item
	cnt = 0;
	pos = m_List.GetFirstSelectedItemPosition();
	while( pos )
	{
		// Retrieve its item number
		nItem = m_List.GetNextSelectedItem( pos );

		// And the SUBFILE ptr
		sf = (SUBFILE *) m_List.GetItemData( nItem );

		// Generate an output name and append to previous folder path
		dest = m_SavePath;
		::PathAppend( dest.GetBuffer( MAX_PATH ),
					  OutputName( sf ) );
		dest.ReleaseBuffer();

		// Extract it
		if( !Extract( sf, dest, nItem ) )
		{
			break;
		}

		cnt++;
	}

	msg.Format( " %d subfiles extracted", cnt );
	m_Status.SetWindowText( msg );

	return;
}

// ====================================================================
// Handle the Extract All button
// ====================================================================
void CvmawinDlg::OnBnClickedExtAll()
{
	CBrowseCtrl dlg;
	CString dest;
	SUBFILE *sf;
	int nItem;
	int cnt = m_List.GetItemCount();

	// Create the "Browse for Folder" dialog
	dlg.SetPathName( m_SavePath );
	dlg.SetButtonStyle( BC_CTL_FOLDERSONLY );

	// And display it
	if( dlg.DoModal() != IDOK )
	{
		return;
	}

	// Remember the path
	m_SavePath = dlg.GetDirectory();

	// Position to first selected item
	for( nItem = 0; nItem < cnt; nItem++ )
	{
		// And the SUBFILE ptr
		sf = (SUBFILE *) m_List.GetItemData( nItem );

		// Generate an output name and append to previous folder path
		dest = m_SavePath;
		::PathAppend( dest.GetBuffer( MAX_PATH ),
					  OutputName( sf ) );
		dest.ReleaseBuffer();

		// Extract it
		if( !Extract( sf, dest, nItem ) )
		{
			break;
		}
	}

	msg.Format( " %d subfiles extracted", nItem );
	m_Status.SetWindowText( msg );

	return;
}

// ====================================================================
// Handle the View button
// ====================================================================
void CvmawinDlg::OnBnClickedView()
{
	POSITION pos;
	SUBFILE *sf;
	CString path;
	CString dest;
	CString cmd;
	int nItem;
	int mode;
	int cnt = m_List.GetSelectedCount();

	// Keep the user on their toes
	if( cnt == 0 )
	{
		MessageBox( "I'd love to oblige, but you need to tell me what to show ya.",
					"Helpful Message" );
		return;
	}

	if( cnt > 1 )
	{
		MessageBox( "I could show you more than 1 file, but I don't feel like it.",
					"Helpful Message" );
		return;
	}

	// Ask Windows where temporary files should go
	::GetTempPath( MAX_PATH, path.GetBuffer( MAX_PATH + 1 ) );
	path.ReleaseBuffer();

	// And respectifully request a unique temporary file name
	::GetTempFileName( path, "VMA", 0, dest.GetBuffer( MAX_PATH + 1 ) );
	dest.ReleaseBuffer();

	// Get positioned to the first selected item
	pos = m_List.GetFirstSelectedItemPosition();
	if( !pos )
	{
		MessageBox( "Weird...I wasn't able to get the first item.  Oh well...",
					"Not So Helpful Message" );
		return;
	}

	// And get its item number
	nItem = m_List.GetNextSelectedItem( pos );

	// Retrieve the SUBFILE pointer
	sf = (SUBFILE *) m_List.GetItemData( nItem );

	// Extract it
	if( !Extract( sf, dest, nItem ) )
	{
		return;
	}

	// Determine how to view the file
	cmd = m_BinViewer;
	mode = GetCheckedRadioButton( IDC_AUTO, IDC_BINARY );
	if( mode == IDC_TEXT || ( mode == IDC_AUTO && sf->dtype == VMAD_TEXT ) )
	{
		cmd = m_TxtViewer;
	}

	// Invoke the viewer app
	if( ::ShellExecute( m_hWnd,
						"open",
						cmd.GetBuffer(),
						dest.GetBuffer(),
						NULL,
						SW_SHOW ) < (HINSTANCE) 32 )
	{
		MessageBox( "Unable to execute viewer", "Really Helpful Message" );
	}
	cmd.ReleaseBuffer();
	dest.ReleaseBuffer();

	// Did you happen to notice we don't delete the temporary file?  :-(
	return;
}

// ====================================================================
// Invoke the Settings dialog
// ====================================================================
void CvmawinDlg::OnBnClickedSettings()
{
	CSettings dlgSettings;
	int rc;

	// Display settings dialog
	dlgSettings.DoModal();

	// Refresh settings
	m_TxtViewer = theApp.GetProfileString( _T( "Settings" ),
										   _T( "Text Viewer" ),
										   _T( "Notepad" ) );

	m_BinViewer = theApp.GetProfileString( _T( "Settings" ),
										   _T( "Binary Viewer" ),
										   _T( "Notepad" ) );

	m_UCMFrom = theApp.GetProfileString( _T( "Settings" ),
										 _T( "From UCM" ),
										 _T( "" ) );

	m_UCMTo = theApp.GetProfileString( _T( "Settings" ),
									   _T( "To UCM" ),
									   _T( "" ) );

	m_Stats = theApp.GetProfileInt( _T( "Settings" ),
									_T( "Subfile Stats" ),
									true );

	m_Action = theApp.GetProfileInt( _T( "Settings" ),
									 _T( "Default Action" ),
									 1 );

	// Reset the conversion tables
	if( m_vma )
	{
		if( !m_UCMFrom.IsEmpty() && !m_UCMTo.IsEmpty() )
		{
			rc = vma_setconv( m_vma,
							  m_UCMFrom.GetBuffer(),
							  m_UCMTo.GetBuffer() );
			m_UCMFrom.ReleaseBuffer();
			m_UCMTo.ReleaseBuffer();

			if( rc != VMAE_NOERR )
			{
				msg.Format( "Conversion table load failed: %d\n", rc );
				MessageBox( msg, "Not So Helpful Message" );
			}
		}
		else
		{
			vma_setconv( m_vma, NULL, NULL );
		}
	}

	return;
}

// ====================================================================
// Validate Pattern when it loses focus
// ====================================================================
void CvmawinDlg::OnEnKillfocusPattern()
{

	// Resupply default Pattern it the user leaves the editbox empty
	if( m_Pattern.GetWindowTextLength() == 0 )
	{
		m_Pattern.SetWindowText( "%n.%t.%m" );
	}

	return;
}
// ====================================================================
// Handle Auto radio button
// ====================================================================
void CvmawinDlg::OnBnClickedAuto()
{
	m_Format = FmtAuto;

	return;
}

// ====================================================================
// Handle Text radio button
// ====================================================================
void CvmawinDlg::OnBnClickedText()
{
	m_Format = FmtText;

	return;
}

// ====================================================================
// Handle Binary radio button
// ====================================================================
void CvmawinDlg::OnBnClickedBinary()
{
	m_Format = FmtBinary;

	return;
}

// ====================================================================
// Handle sort requests
// ====================================================================
void CvmawinDlg::OnLvnColumnclickList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);

	Field sortby = static_cast<Field>( pNMLV->iSubItem + 1 );

	if( m_sortby == sortby )
	{
		m_sortby = static_cast<Field>( -m_sortby );
	}
	else
	{
		m_sortby = sortby;
	}

	m_List.EnableSortIcon( TRUE );
	m_List.ColorSortColumn( TRUE );
	m_List.SortItems( Compare, m_sortby );
	
	*pResult = 0;
}

// ====================================================================
// Double clicking a List entry defaults to View
// ====================================================================
void CvmawinDlg::OnNMDblclkList(NMHDR *pNMHDR, LRESULT *pResult)
{
	// Just let the button click action handle it
	if( m_Action )
	{
		OnBnClickedView();
	}
	else
	{
		OnBnClickedExtract();
	}

	*pResult = 0;
}

/* ********************************************************************
|| Accelerator key handlers                                          ||
******************************************************************** */

// ====================================================================
// Handle CTRL+A for List and Edit controls
// ====================================================================
void CvmawinDlg::OnCtrlA()
{
	CWnd *wnd = GetFocus();
	int cnt;
	int ndx;

	// Was the List control active?
	if( wnd->m_hWnd == m_List.m_hWnd )
	{
		// Select all of the items
		cnt = m_List.GetItemCount();
		for( ndx = 0; ndx < cnt; ndx++ )
		{
			m_List.SetItemState( ndx, LVIS_SELECTED, LVIS_SELECTED );
		}
	}

	// Was the Pattern control active?
	else if( wnd->m_hWnd == m_Pattern.m_hWnd )
	{
		// Select entire contents
		m_Pattern.SetSel( 0, -1 );
	}

	return;
}

// ====================================================================
// Handle ENTER for List control
// ====================================================================
void CvmawinDlg::OnEnter()
{
	// Only care about the List control
	if( GetFocus()->m_hWnd == m_List.m_hWnd )
	{
		// Just let the button click action handle it
		if( m_Action )
		{
			OnBnClickedView();
		}
		else
		{
			OnBnClickedExtract();
		}
	}

	return;
}
