VMA - Unarchiver for VMARC files


WHAT
----------
This small utility allows you to list and/or extract subfiles
from a VMARC archive file.  These files are created on the 
VM operating system, so if you don't know what that is, you
probably don't need VMA.

I used the latest VMARC source to create a portable version
in C.  You can find the latest assembler source at:

http://www.geocities.com/RossPatterson/vmarc/

They are currently maintained by Ross Patterson and VMARC
was originally written by John Fisher.


WHY
----------
Cause I'm lazy.  :-)  It was just too much work to upload a
VMARC to VM just to take a look at it.


WHEN
----------
One weekend in the summer of '05 when I should've been working on
other projects.


WHO
---------
Leland Lucius (that's me) - this utility

Ross Patterson - current VMARC maintainer

John Fisher - original creator of VMARC

ozan s. yigit - glob pattern matcher


CONTRIBS
----------
Alex Brodsky
Kris Buelens
Perry Ruiter
Adam Thornton


HOW
----------
Despite what I say in the next 2 sections, feel free to contact
me if you find a bug.  I'll do my best to stomp on it.  But, my
depth perception is getting worse in my old age so it my take
me a few trys to get it.  :-)

Email:  vma@homerow.net


COPYRIGHT
----------
I reckon I own the copyrights to this utility since it is sort
of an original work.  But, as it's based on John Fisher's work
I wouldn't feel right about making any clains to ownership.

So, I therefore release VMA into the public domain.  Do with it
as you like.  Mutilate it, molest it, spindle it, fondle it, or
whatever else.

It wouldn't be very nice if you made money off of it, but if 
that's what you want to do...knock yourself out.


DISCLAIMER
----------
If VMA breaks or breaks anything around it...too bad.  You
have made the decision to use it and are therefor responsible
for what happens.

I built the gun, but I didn't pull the trigger.  :-D
