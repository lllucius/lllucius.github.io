#if !defined( _VMA_H )
#define _VMA_H

/* --------------------------------------------------------------------
|| Subfile information
*/
typedef struct subfile
{
    unsigned char   ver;                /* version of creating VMARC */
    unsigned char   rel;               /* revision of creating VMARC */
    unsigned char   meth[ 5 ];      /* storage method: ASIS, LZW, S2 */
    unsigned char   fn[ 9 ];                      /* null terminated */
    unsigned char   ft[ 9 ];                      /* null terminated */
    unsigned char   fm[ 3 ];                      /* null terminated */
    int             lrecl;                         /* possibly > 64k */
    int             year;
    unsigned char   month;
    unsigned char   day;
    unsigned char   hour;
    unsigned char   minute;
    unsigned char   second;
    unsigned char   recfm;
    unsigned int    ibytes;
    unsigned int    obytes;
    unsigned char   dtype;                  /* data type TRUE = text */
} SUBFILE;

/* --------------------------------------------------------------------
|| SUBFILE::dtype is only a best guess and is determined by examining
|| the first 1024 bytes of each subfile and, if any bytes fall below
|| 0x20, the mode value will be set to BINARY.
*/
#define VMAD_UNKNOWN    0
#define VMAD_TEXT       1
#define VMAD_BINARY     2

/* --------------------------------------------------------------------
|| Extraction mode
*/
#define VMAX_AUTO       0                   /* use SUBFILE:Ldtype    */
#define VMAX_TEXT       1                   /* convert to text+LF    */
#define VMAX_TRANS      2                   /* translate             */
#define VMAX_BINARY     3                   /* extract unchanged     */

/* --------------------------------------------------------------------
|| Errors
*/
#define VMAE_NOERR      0                   /* no error              */
#define VMAE_RERR       1                   /* read error            */
#define VMAE_WERR       2                   /* write error           */
#define VMAE_OOVER      3                   /* output overflow       */
#define VMAE_INACT      4                   /* no active subfile     */
#define VMAE_OOPEN      5                   /* open output failed    */
#define VMAE_IOPEN      6                   /* open input failed     */
#define VMAE_MEM        7                   /* insufficient memory   */
#define VMAE_TIME       8                   /* set file times failed */
#define VMAE_SEEK       9                   /* repositioning failed  */
#define VMAE_BADARG     10                  /* missing parameter     */
#define VMAE_NOMORE     11                  /* mo more subfiles      */
#define VMAE_NOTFOUND   12                  /* subfile not found     */
#define VMAE_NEEDMORE   13                  /* expected more data    */
#define VMAE_UCMOPEN    14                  /* UCM open failed       */
#define VMAE_UCMSBCS    15                  /* only SBCS UCMs okay   */
#define VMAE_SUBCHAR    16                  /* invalid UCM subchar   */
#define VMAE_CHARMAP    17                  /* missing or bad cmap   */
#define VMAE_LRECL      18                  /* LRECL exceeds max     */

/* --------------------------------------------------------------------
|| Public functions
*/
extern int vma_open( char *name, int size, void **vma );
extern void vma_close( void *vma );
extern int vma_first( void *vma, SUBFILE **sf );
extern int vma_next( void *vma, SUBFILE **sf );
extern int vma_setactive( void *vma, SUBFILE *sf );
extern int vma_extract( void *vma, char *name, int ascii );
extern int vma_setconv( void *vma, char *fucm, char *tucm );

#endif
