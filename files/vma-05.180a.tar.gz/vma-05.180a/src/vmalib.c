/* ====================================================================
||
|| vma - A utility to list and extract contents of VMARC archive files
||
==================================================================== */
#define _ALL_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <errno.h>
#include <ctype.h>
#include <time.h>

#if defined( __MVS__ ) || defined( linux ) || defined( __APPLE__ )
#include <utime.h>
#if defined( __MVS__ )
#include <sys/utsname.h>
#endif
#else
#include <sys/utime.h>
#endif

#if !defined( _WIN32 )
#include <unistd.h>
#endif

#include "vma.h"
#include "vmalib.h"
#include "version.h"

/* --------------------------------------------------------------------
|| General stuff
*/
#if !defined( VERSION )
#define VERSION "\"homegrown\""
#endif

#if !defined( NULL )
#define NULL 0
#endif

#if !defined( TRUE )
#define TRUE 1
#endif

#if !defined( FALSE )
#define FALSE 0
#endif

/* --------------------------------------------------------------------
|| Conversion stuff
*/
#define CONV( c ) ( vma->cmap[ c ] )
#define DLM " \t\n"

typedef struct _ent
{
    int u;
    int b;
} ENT;

/* --------------------------------------------------------------------
|| IBM-1047 -> IBM-1047
*/
static const uchar
e2e_tab[] =
{
    "\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f"
    "\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f"
    "\x20\x21\x22\x23\x24\x25\x26\x27\x28\x29\x2a\x2b\x2c\x2d\x2e\x2f"
    "\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x3a\x3b\x3c\x3d\x3e\x3f"
    "\x40\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4a\x4b\x4c\x4d\x4e\x4f"
    "\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5a\x5b\x5c\x5d\x5e\x5f"
    "\x60\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6a\x6b\x6c\x6d\x6e\x6f"
    "\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7a\x7b\x7c\x7d\x7e\x7f"
    "\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89\x8a\x8b\x8c\x8d\x8e\x8f"
    "\x90\x91\x92\x93\x94\x95\x96\x97\x98\x99\x9a\x9b\x9c\x9d\x9e\x9f"
    "\xa0\xa1\xa2\xa3\xa4\xa5\xa6\xa7\xa8\xa9\xaa\xab\xac\xad\xae\xaf"
    "\xb0\xb1\xb2\xb3\xb4\xb5\xb6\xb7\xb8\xb9\xba\xbb\xbc\xbd\xbe\xbf"
    "\xc0\xc1\xc2\xc3\xc4\xc5\xc6\xc7\xc8\xc9\xca\xcb\xcc\xcd\xce\xcf"
    "\xd0\xd1\xd2\xd3\xd4\xd5\xd6\xd7\xd8\xd9\xda\xdb\xdc\xdd\xde\xdf"
    "\xe0\xe1\xe2\xe3\xe4\xe5\xe6\xe7\xe8\xe9\xea\xeb\xec\xed\xee\xef"
    "\xf0\xf1\xf2\xf3\xf4\xf5\xf6\xf7\xf8\xf9\xfa\xfb\xfc\xfd\xfe\xff"
};

/* --------------------------------------------------------------------
|| IBM-1047 -> ISO-8859-1
*/
static const uchar
e2a_tab[] =
{
    "\x00\x01\x02\x03\x9c\x09\x86\x7f\x97\x8d\x8e\x0b\x0c\x0d\x0e\x0f"
    "\x10\x11\x12\x13\x9d\x85\x08\x87\x18\x19\x92\x8f\x1c\x1d\x1e\x1f"
    "\x80\x81\x82\x83\x84\x0a\x17\x1b\x88\x89\x8a\x8b\x8c\x05\x06\x07"
    "\x90\x91\x16\x93\x94\x95\x96\x04\x98\x99\x9a\x9b\x14\x15\x9e\x1a"
    "\x20\xa0\xe2\xe4\xe0\xe1\xe3\xe5\xe7\xf1\xa2\x2e\x3c\x28\x2b\x7c"
    "\x26\xe9\xea\xeb\xe8\xed\xee\xef\xec\xdf\x21\x24\x2a\x29\x3b\x5e"
    "\x2d\x2f\xc2\xc4\xc0\xc1\xc3\xc5\xc7\xd1\xa6\x2c\x25\x5f\x3e\x3f"
    "\xf8\xc9\xca\xcb\xc8\xcd\xce\xcf\xcc\x60\x3a\x23\x40\x27\x3d\x22"
    "\xd8\x61\x62\x63\x64\x65\x66\x67\x68\x69\xab\xbb\xf0\xfd\xfe\xb1"
    "\xb0\x6a\x6b\x6c\x6d\x6e\x6f\x70\x71\x72\xaa\xba\xe6\xb8\xc6\xa4"
    "\xb5\x7e\x73\x74\x75\x76\x77\x78\x79\x7a\xa1\xbf\xd0\x5b\xde\xae"
    "\xac\xa3\xa5\xb7\xa9\xa7\xb6\xbc\xbd\xbe\xdd\xa8\xaf\x5d\xb4\xd7"
    "\x7b\x41\x42\x43\x44\x45\x46\x47\x48\x49\xad\xf4\xf6\xf2\xf3\xf5"
    "\x7d\x4a\x4b\x4c\x4d\x4e\x4f\x50\x51\x52\xb9\xfb\xfc\xf9\xfa\xff"
    "\x5c\xf7\x53\x54\x55\x56\x57\x58\x59\x5a\xb2\xd4\xd6\xd2\xd3\xd5"
    "\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\xb3\xdb\xdc\xd9\xda\x9f"
};

/* --------------------------------------------------------------------
|| Loads character mappings from UCM format files
*/
static int
loaducm( VMA *vma, char *name, ENT *map, int *subchar )
{
    FILE *f;
    char *token;
    char line[ 256 ];
    int f_schr = FALSE;
    int f_cmap = FALSE;
    int f_emap = FALSE;
    int f_sbcs = FALSE;
    int u;
    int b;

    /*
    || Set output to default state
    */
    memset( map, '\0', sizeof( ENT ) * 256 );
    *subchar = -1;

    /*
    || Open the UCM
    */
    f = fopen( name, "r" );
    if( f == NULL )
    {
        seterr( VMAE_UCMOPEN );
        return FALSE;
    }

    /*
    || Read all of the lines
    */
    while( fgets( line, sizeof( line ), f )  )
    {
        /*
        || Get the first word
        */
        token = strtok( line, DLM );
        if( token == NULL )
        {
            continue;
        }

        /*
        || Ignore comments and empty lines
        */
        if( token[ 0 ] == '#' || token[ 0 ] == '\0' )
        {
            continue;
        }

        /*
        || Start of the character mapping?
        */
        if( strcmp( token, "CHARMAP" ) == 0 )
        {
            /*
            || Ensure we have an SBCS before allowing CHARMAP
            */
            if( !f_sbcs )
            {
                seterr( VMAE_UCMSBCS );
                break;
            }

            /*
            || Indicate that we're now processing the mappings
            */
            f_cmap = TRUE;
            continue;
        }

        /*
        || End of the character mapping?
        */
        if( strcmp( token, "END" ) == 0 )
        {
            /*
            || Get the next word
            */
            token = strtok( NULL, DLM );
            if( token == NULL )
            {
                continue;
            }

            /*
            || And ensure it's the end of the table
            */
            if( strcmp( token, "CHARMAP" ) != 0 )
            {
                continue;
            }

            /*
            || Not process the table...tsk, tsk
            */
            if( !f_cmap )
            {
                seterr( VMAE_CHARMAP );
                break;
            }

            /*
            || All done, indicate possible success
            */
            f_emap = TRUE;
            break;
        }

        /*
        || Check to make sure we have an SBCS mapping
        */
        if( strcmp( token, "<uconv_class>" ) == 0 )
        {
            /*
            || Get the next word
            */
            token = strtok( NULL, DLM );
            if( token == NULL )
            {
                continue;
            }

            /*
            || Ensure we have an SBCS mapping
            */
            if( strcmp( token, "\"SBCS\"" ) != 0 )
            {
                seterr( VMAE_UCMSBCS );
                break;
            }

            /*
            || Indicate such
            */
            f_sbcs = TRUE;
            continue;
        }

        /*
        || Remember the substitution character
        */
        if( strcmp( token, "<subchar>" ) == 0 )
        {
            /*
            || Get the next word
            */
            token = strtok( NULL, DLM );
            if( token == NULL )
            {
                continue;
            }

            /*
            || Look like a hex value?
            */
            if( token[ 0 ] != '\\' || token[ 1 ] != 'x' )
            {
                seterr( VMAE_SUBCHAR );
                break;
            }

            /*
            || Convert it
            */
            *subchar = (int) strtoul( &token[ 2 ], NULL, 16 );
            f_schr = TRUE;
            continue;
        }

        /*
        || Ignore anything else if we're not processing mapping entries
        */
        if( !f_cmap )
        {
            continue;
        }

        /*
        || Make sure it looks like a unicode scalar
        */
        if( token[ 0 ] != '<' || token[ 1 ] != 'U' )
        {
            seterr( VMAE_CHARMAP );
            break;
        }

        /*
        || Get the value
        */
        u = (int) strtoul( &token[ 2 ], &token, 16 );

        /*
        || Terminated correctly?
        */
        if( token[ 0 ] != '>' )
        {
            seterr( VMAE_CHARMAP );
            break;
        }

        /*
        || Get the next word
        */
        token = strtok( NULL, DLM );
        if( token == NULL )
        {
            continue;
        }

        /*
        || Look like a hex value?
        */
        if( token[ 0 ] != '\\' || token[ 1 ] != 'x' )
        {
            seterr( VMAE_CHARMAP );
            break;
        }

        /*
        || Convert it
        */
        b = (int) strtoul( &token[ 2 ], &token, 16 );

        /*
        || Nothing strange following it?
        */
        if( token[ 0 ] != '\0' )
        {
            seterr( VMAE_CHARMAP );
            break;
        }

        /*
        || Get the next word
        */
        token = strtok( NULL, DLM );
        if( token == NULL )
        {
            continue;
        }


        /*
        || Only allow direct mappings
        */
        if( strcmp( token, "|0" ) != 0 )
        {
            continue;
        }

        /*
        || Save the value
        */
        map[ b ].u = u;
        map[ b ].b = b;

        /*
        || Just ignore the rest of the line
        */
        continue;
    }

    /*
    || Done with the UCM
    */
    fclose( f );

    /*
    || Something happened...
    */
    if( !f_emap )
    {
        return FALSE;
    }

    /*
    || Looks like we were successful
    */
    return TRUE;
}

/* --------------------------------------------------------------------
|| Compares entries during sorting and searching
*/
static int
cmp( const void *e1, const void *e2 )
{
    return ( (ENT *)e1 )->u - ( (ENT *)e2 )->u;
}

/* --------------------------------------------------------------------
|| General I/O stuff
*/
static void
unget( VMA *vma, uchar *buf, int len )
{
    while( --len > 0 )
    {
        vma->ibuf[ --vma->ibufp ] = buf[ len ];
        vma->icnt++;
    }

    return;
}

/* --------------------------------------------------------------------
|| Get a character from the VMARC
*/
static unsigned int
get( VMA *vma )
{
    /*
    || Need to refill the buffer?
    */
    if( vma->icnt == 0 )
    {
        /*
        || Check for EOF
        */
        if( feof( vma->in ) )
        {
            return (unsigned int) EOF;
        }

        /*
        || Remember file position corresponding to start of buffer
        */
        vma->ipos = ftell( vma->in );

        /*
        || Read a buffers worth
        */
        vma->icnt = fread( &vma->ibuf[ UNREAD ], 1, BUFLEN, vma->in );

        /*
        || Check for errors...defer EOF check for later
        */
        if( ferror( vma->in ) )
        {
            seterr( VMAE_RERR );

            return (unsigned int) EOF;
        }

        /*
        || Reset buffer position
        */
        vma->ibufp = UNREAD;
    }

    /*
    || Track # of bytes read...resets at start of subfile extraction
    */
    vma->bytesin++;

    /*
    || One less byte in the buffer
    */
    vma->icnt--;

    return (unsigned int) vma->ibuf[ vma->ibufp++ ];
}

/* --------------------------------------------------------------------
|| Returns current input position in the VMARC
*/
static int
mytell( VMA *vma )
{
    /*
    || Return the current input position
    ||
    || Accounts for any "unget()" bytes too.
    */
    return vma->ipos + ( vma->ibufp - UNREAD );
}

/* --------------------------------------------------------------------
|| Writes a byte to the extract file
*/
static int
put( VMA *vma, unsigned int c )
{
    /*
    || Track the number of bytes we've written (for display)
    */
    if( c != UINT_MAX )
    {
        vma->bytesout++;

        if( vma->bytesout <= 1024 )
        {
            if( c < 0x20 )
            {
                vma->dtype = VMAD_BINARY;
            }
        }
    }

    /*
    || Nothing else to do if we're not extracting
    */
    if( !vma->f_extract )
    {
        return TRUE;
    }

    /*
    || Flush the output buffer
    */
    if( c == UINT_MAX )
    {
        if( fwrite( vma->obuf, 1, vma->opos, vma->out ) != vma->opos )
        {
            seterr( VMAE_WERR );
            return FALSE;
        }

        vma->opos = 0;

        return TRUE;
    }

    /*
    || Make sure we don't overflow
    */
    if( vma->opos == vma->omax )
    {
        seterr( VMAE_OOVER );
        return FALSE;
    }

    /*
    || Store the character
    */
    vma->obuf[ vma->opos++ ] = c;

    return TRUE;
}

/* --------------------------------------------------------------------
|| Shared compression I/O
*/
static int
putbyte( VMA *vma, unsigned short c )
{
    int code;

    /*
    || Convert back to EBCDIC character
    */
    code = c - kodebcd;

    /*
    || Handle special codes (only EOR)
    */
    if( code < 0 )
    {
        /*
        || Track number of times we've seen the EOR code
        */
        vma->eor++;

        /*
        || Variable records:
        || First means end-of-record...second one means end-of-file
        ||
        || Fixed records:
        || First means end-of-file
        */
        if( vma->eor > 1 || vma->recfm == 'F' )
        {
            if( !put( vma, UINT_MAX ) )
            {
                return -1;
            }

            return 0;
        }

        /*
        || Append a line end if converting
        */
        if( vma->f_text )
        {
#if defined( _WIN32 )
            if( !put( vma, '\r' ) )
            {
                return -1;
            }
#endif
            if( !put( vma, '\n' ) )
            {
                return -1;
            }
        }

        if( !put( vma, UINT_MAX ) )
        {
            return -1;
        }

        return 1;
    }

    /*
    || Reset EOR counter
    */
    vma->eor = 0;

    /*
    || Bail out if we're scanning and have hit our limit
    */
    if( vma->f_scanning && vma->bytesin >= 1024 )
    {
        return 0;
    }

    /*
    || Fixed files need record length tracking to output newline since
    || we don't receive an EOR code for them.
    */
    if( vma->recfm == 'F' )
    {
        if( vma->recbytes == vma->lrecl )
        {
            vma->recbytes = 0;

            if( vma->f_text )
            {
#if defined( _WIN32 )
                if( !put( vma, '\r' ) )
                {
                    return -1;
                }
#endif
                if( !put( vma, '\n' ) )
                {
                    return -1;
                }
            }

            if( !put( vma, UINT_MAX ) )
            {
                return -1;
            }
        }

        vma->recbytes++;
    }

    /*
    || Translate
    */
    if( vma->f_trans )
    {
        code = CONV( code );
    }

    /*
    || Put the byte
    */
    if( !put( vma, code ) )
    {
        return -1;
    }

    return 1;
}

static unsigned short
getcode( VMA *vma )
{
    unsigned int code;

    /*
    || Always need need to read as least one byte
    */
    code = get( vma );
    if( code == EOF )
    {
        return USHRT_MAX;
    }

    /*
    || Use what's left over from previous call
    */
    if( vma->residual != UINT_MAX )
    {
        code |= ( vma->residual << 8 );
        vma->residual = UINT_MAX;
    }
    else
    {
        /*
        || Get the low 4 bits of the 12 bit code
        */
        vma->residual = get( vma );
        if( vma->residual == EOF )
        {
            return USHRT_MAX;
        }

        /*
        || And put it where it belongs
        */
        code = ( code << 4 ) | ( vma->residual >> 4 );
    }

    /*
    || Always returns a 12 bit code
    */
    return code & 0xfff;
}

/* --------------------------------------------------------------------
|| LZW Decompression
*/
static LZWSTRING *
lookup( VMA *vma, LZWSTRING *lastpred, unsigned short nextchar )
{
    unsigned int offset;
    LZWSTRING *bucket;
    LZWSTRING *origin;
    LZWSTRING *left;
    LZWSTRING *right;
    int wrapped;

    /*
    || Hash function.
    */
    offset = ( ( ( (unsigned long)lastpred ) >> 3 ) ^ nextchar )
           & 0xffff;
    offset *= offset;
    offset %= HASHSIZE;

    /*
    || Locate start of hash chain
    */
    bucket = (LZWSTRING *) &vma->lzwhashtab[ offset ];
    origin = bucket;

    /*
    || Search hash table for (predecessor,character) combination.
    */
    while( bucket->right != origin )
    {
        if( bucket->pred == lastpred && bucket->schar == nextchar )
        {
            /* found it */
            return bucket;
        }

        bucket = bucket->right;
    }

    /*
    || Desired entry not found.  Add it if possible.
    */

    /*
    || Bump reference count of previous predecessor
    */
    if( lastpred != ENDCHAIN )
    {
        lastpred->refcnt++;
    }

    /*
    || Search for free entry until end of table is reached
    */
    wrapped = 0;
    do
    {
        /*
        || Bump to next table entry
        */
        ++vma->lzwtabp;

        /*
        || Reached the end of the table?
        */
        if( vma->lzwtabp > vma->lzwtabl )
        {
            /*
            || Get out if we've been here before
            */
            if( wrapped )
            {
                break;
            }

            wrapped = 1;
            vma->lzwtabp = vma->lzwtabs;
        }
    } while( vma->lzwtabp->refcnt != 0 );

    /*
    || If we hit the KwKwK case, then don't add this entry
    || to the table. (big flower box in VMARC source)
    */
    if( vma->lzwtabp > vma->lzwtabl )
    {
        lastpred->refcnt--;

        /*
        || Indicate it wasn't found
        */
        return NULL;
    }

    /*
    || Remove entry from previous location in hash and prefix chains
    */
    if( vma->lzwtabp->right != 0 )
    {
        right = vma->lzwtabp->right;
        left = vma->lzwtabp->left;
        right->left = left;
        left->right = right;
        if( vma->lzwtabp->pred != 0 )
        {
            vma->lzwtabp->pred->refcnt--;
        }
    }

    /*
    || Add it to its new home in the prefix chain
    */
    vma->lzwtabp->pred = lastpred;
    vma->lzwtabp->schar = nextchar;
    vma->lzwtabp->refcnt = 0;

    /*
    || And in the hash chain
    */
    right = origin->right;
    vma->lzwtabp->right = right;
    vma->lzwtabp->left = origin;
    origin->right = vma->lzwtabp;
    right->left = vma->lzwtabp;

    /*
    || Return entry
    */
    return vma->lzwtabp;
}

static void
lzwinit( VMA *vma )
{
    LZWSTRING *ent;
    LZWHASH *hash;
    unsigned short ndx;

    /*
    || Clear the prefix table
    */
    memset( vma->lzwstrtab, 0, sizeof( vma->lzwstrtab ) );

    /*
    || Initialize the hash table
    */
    hash = &vma->lzwhashtab[ 0 ];
    for( ndx = 0; ndx < HASHSIZE; ndx++ )
    {
        hash->head = (LZWSTRING *) hash;
        hash->tail = (LZWSTRING *) hash;
        hash++;
    }

    /*
    || Preload the specials plus 256 EBCDIC characters
    */
    vma->lzwtabp = &vma->lzwstrtab[ 0 ] - 1; /* -1 for lookup preinc */
    vma->lzwtabl = &vma->lzwstrtab[ TABSIZE - 1 ];

    for( ndx = 0; ndx < kodmax + 1; ndx++ )
    {
        /*
        || Force addition of entry and set reference count
        */
        ent = lookup( vma, ENDCHAIN, ndx );
        ent->refcnt = 1;
    }

    /*
    || Set wrap-around point
    */
    vma->lzwtabs = ent + 1;

    return;
}

static int
extract_lzw( VMA *vma )
{
    LZWSTRING *prev;
    LZWSTRING *last;
    LZWSTRING *ent;
    LZWSTRING *tabptr;
    int wrapped;
    unsigned short code;
    int rc;

    /*
    || Initialize
    */
    lzwinit( vma );
    tabptr = vma->lzwtabs;
    tabptr->pred = ENDCHAIN;

    while( TRUE )
    {
        /*
        || Get the next code
        */
        code = getcode( vma );
        if( code == USHRT_MAX )
        {
            return FALSE;
        }

        /*
        || Traverse down to get to the start of the string
        */
        ent = &vma->lzwstrtab[ code ];
        prev = ENDCHAIN;
        do
        {
            last = ent->pred;
            ent->pred = prev;
            prev = ent;
            ent = last;
        } while( ent != ENDCHAIN );

        /*
        ||
        */
        tabptr->schar = prev->schar;

        /*
        || Go back up while outputing the characters in correct order
        */
        do
        {
            rc = putbyte( vma, prev->schar );
            if( rc == 0 )
            {
                return TRUE;
            }
            if( rc < 0 )
            {
                return FALSE;
            }

            last = prev->pred;
            prev->pred = ent;
            ent = prev;
            prev = last;
        } while( prev != ENDCHAIN );

        /*
        || Start building follow-on entry for this code.
        */
        ent->refcnt++;

        /*
        || Search for free entry until end of table is reached
        */
        wrapped = FALSE;
        tabptr = vma->lzwtabp;
        do
        {
            /*
            || Bump to next table entry
            */
            ++tabptr;

            /*
            || Reached the end of the table?
            */
            if( tabptr > vma->lzwtabl )
            {
                /*
                || Get out if we've been here before
                */
                if( wrapped )
                {
                    break;
                }

                wrapped = TRUE;
                tabptr = vma->lzwtabs;
            }
        } while( tabptr->refcnt );

        /*
        || If we hit the KwKwK case, then don't add this entry
        || to the table. (big flower box in VMARC source)
        */
        if( tabptr > vma->lzwtabl )
        {
            ent->refcnt--;
            continue;
        }

        /*
        || Add the new entry
        */
        if( tabptr->pred != ENDCHAIN && tabptr->pred != NULL )
        {
            tabptr->pred->refcnt--;
        }

        /*
        || Remember for next round
        */
        tabptr->pred = ent;
        vma->lzwtabp = tabptr;
    }

    return TRUE;
}

/* --------------------------------------------------------------------
|| S2 Decompression
*/
static void
s2addnew( VMA *vma, unsigned short slastcode, unsigned short lastcode  )
{
    struct strdsect *left;
    struct strdsect *right;
    struct strdsect *probe;
    struct strdsect *ostr;
    struct strdsect **psib;
    struct strdsect **opsib;

    /*
    || Find string table entries for the left and right substrings
    */
    left = &vma->s2strtab[ slastcode ];
    right = &vma->s2strtab[ lastcode ];

    /*
    || Would string be longer with buffer?
    */
    if( ( left->strlen + right->strlen ) > ( TABSIZE - 2 ) )
    {
        return;
    }

    left->strcount++;
    right->strcount++;

    /*
    || Find a place for the new string
    */
    probe = vma->s2tabp;
    do
    {
        probe++;
        if( probe > vma->s2tabl )
        {
            probe = vma->s2tabs;
        }
    } while( probe->strcount != 0 );

    /*
    || Replace an old string entry with this new one
    */
    ostr = probe->strleft;
    if( ostr )
    {
        ostr->strcount--;

        psib = &ostr->stroffsp;
        while( *psib != probe )
        {
            psib = &( *psib )->strsiblg;
        }
        *psib = probe->strsiblg;

        ostr = probe->strright;
        ostr->strcount--;
    }

    /*
    || Now construct a new entry for this string
    */
    if( right == vma->s2tabp )
    {
        if( left == right->strleft )
        {
            ostr = right;
            right = left;
            left = ostr;
        }
    }

    probe->strleft = left;
    probe->strright = right;
    probe->strlen = 2 + left->strlen + right->strlen;

    /*
    || Insert new node into offspring/sibling list of left substring
    */
    psib = &left->stroffsp;
    do
    {
        opsib = psib;
        left = *psib;
        psib = &left->strsiblg;
    } while( left && ( left != vma->s2tabp ) );

    probe->strsiblg = left;
    *opsib = probe;
    vma->s2tabp = probe;

    return;
}

static void
s2init( VMA *vma )
{
    unsigned short ndx;

    memset( &vma->s2strtab, 0, sizeof( vma->s2strtab ) );

    vma->s2tabs = &vma->s2strtab[ kodmax + 1 ];
    vma->s2tabl = &vma->s2strtab[ TABSIZE ];
    vma->s2tabp = vma->s2tabl;

    for( ndx = 0; ndx < kodmax + 1; ndx++ )
    {
        vma->s2strtab[ ndx ].strchar = ndx;
        vma->s2strtab[ ndx ].strcount = 1;
    }

    return;
}

static int
extract_s2( VMA *vma )
{
    struct strdsect *prev;
    struct strdsect *curr;
    struct strdsect *next;
    unsigned short slastcode;
    unsigned short lastcode;
    int rc;

    /*
    || Intialize tables
    */
    s2init( vma );

    /*
    || Retrieve and remember the first code
    */
    slastcode = getcode( vma );
    if( slastcode == USHRT_MAX )
    {
        return FALSE;
    }

    /*
    || Output the first code
    */
    rc = putbyte( vma, slastcode );
    if( rc < 0 )
    {
        return FALSE;
    }

    /*
    || EOF is okay at this point
    */
    if( rc == 0 )
    {
        return TRUE;
    }

    while( TRUE )
    {
        lastcode = getcode( vma );
        if( slastcode == USHRT_MAX )
        {
            return FALSE;
        }

        curr = &vma->s2strtab[ lastcode ];
        prev = NULL;
        do
        {
            /*
            || Drop down as far as possible along the leftmost path
            */
            do
            {
                next = curr->strleft;
                curr->strleft = prev;
                prev = curr;
                curr = next;
            } while( curr );

            /*
            || We have hit the bottom
            */
            curr = prev;
            prev = curr->strleft;
            curr->strleft = next;
            rc = putbyte( vma, curr->strchar );
            if( rc < 0 )
            {
                return FALSE;
            }

            /*
            || Done...
            */
            if( rc == 0 )
            {
                return TRUE;
            }

            /*
            || Retrace path up looking for the first unexplored right
            || path
            */
            while( TRUE )
            {
                next = curr;
                curr = prev;

                /*
                || Reached the root
                */
                if( !curr )
                {
                    break;
                }

                /*
                || Have another right side to traverse
                */
                if( !curr->visited )
                {
                    prev = curr->strleft;
                    curr->strleft = next;

                    next = curr->strright;
                    curr->strright = prev;

                    curr->visited = TRUE;

                    prev = curr;
                    curr = next;
                    break;
                }

                /*
                || Move back up a level
                */
                curr->visited = FALSE;
                prev = curr->strright;
                curr->strright = next;
            }
        } while( curr );

        /*
        || Extend string table with new entry
        */
        s2addnew( vma, slastcode, lastcode );
        slastcode = lastcode;
    }

    return TRUE;
}

/* --------------------------------------------------------------------
|| ASIS stuff
*/
static int
extract_asis( VMA *vma )
{
    int lrecl;
    unsigned int h;
    unsigned int l;
    int rc;

    while( TRUE )
    {
        /*
        || Get the reccord length
        */
        h = get( vma );
        if( h == EOF )
        {
            break;
        }

        l = get( vma );
        if( l == EOF )
        {
            seterr( VMAE_NEEDMORE );
            return FALSE;
        }

        /*
        || Reconstruct lrecl
        */
        lrecl = ( h << 8 ) + l;

        /*
        || Done when we get a zero LRECL
        */
        if( lrecl == 0 )
        {
            break;
        }

        /*
        || Copy input to output
        */
        while( lrecl-- )
        {
            l = get( vma );
            if( l == EOF )
            {
                seterr( VMAE_NEEDMORE );
                return FALSE;
            }

            rc = putbyte( vma, l + kodebcd );
            if( rc < 0 )
            {
                seterr( VMAE_NEEDMORE );
                return FALSE;
            }
        }

        /*
        || Force EOR for variable files only
        */
        if( vma->recfm == 'V' )
        {
            rc = putbyte( vma, 0 );
            if( rc < 0 )
            {
                seterr( VMAE_NEEDMORE );
                return FALSE;
            }
        }
    }

    /*
    || Force EOF
    */
    rc = putbyte( vma, 0 );
    if( rc < 0 )
    {
        return FALSE;
    }

    return TRUE;
}

static int
extract( VMA *vma, int flags )
{
    int rc;

    /*
    || Get properly positioned
    */
    if( fseek( vma->in, vma->active->offset, SEEK_SET ) != 0 )
    {
        seterr( VMAE_SEEK );
        return FALSE;
    }

    /*
    || Cache RECFM and LRECL
    */
    vma->recfm = vma->active->sf.recfm;
    vma->lrecl = vma->active->sf.lrecl;

    /*
    || Reset various counters and I/O controls
    */
    vma->ibufp = 0;
    vma->icnt = 0;
    vma->bytesin = 0;
    vma->bytesout = 0;
    vma->residual = UINT_MAX;
    vma->recbytes = 0;
    vma->eor = 0;
    vma->dtype = VMAD_TEXT;    /* assume text for now */

    /*
    || Extract based on storage type
    */
    if( flags & HF_ASIS )
    {
        rc = extract_asis( vma );
    }
    else if ( flags & HF_S2 )
    {
        rc = extract_s2( vma );
    }
    else
    {
        rc = extract_lzw( vma );
    }

    if( rc )
    {
        if( vma->active->sf.dtype == VMAD_UNKNOWN )
        {
            vma->active->sf.dtype = vma->dtype;
        }

        if( !vma->f_scanning )
        {
            vma->active->sf.ibytes = vma->bytesin;
            vma->active->sf.obytes = vma->bytesout;
        }
    }

    return rc;
}

/* --------------------------------------------------------------------
|| Convert decimal byte to binary
*/
static int
cvb( int dec )
{
    int bin;

    /*
    || Mask out any unwanteds...shouldn't be any
    */
    dec &= 0xff;

    /*
    || Get the "tens" digit
    */
    bin = ( dec >> 4 ) * 10;

    /*
    || And add in the "ones" digit
    */
    bin += ( dec & 0x0f );

    return bin;
}

/*
|| Searches for the next header (There HAS to be a better way!)
||
|| If you can think of way to do this better, PLEASE let me know.
*/
static const uchar hid[ 9 ] = "\x7a\xc3\xc6\xc6\x40\x40\x40\x40";
static int
locate_file( VMA *vma )
{
    unsigned int byte;
    int cnt;
    int ndx;

    while( TRUE )
    {
        ndx = 0;
        while( ndx < sizeof( hid ) - 1 )
        {
            byte = get( vma );
            if( byte == EOF )
            {
                return FALSE;
            }

            if( byte == hid[ ndx ] )
            {
                ndx++;
            }
            else if( byte == hid[ 0 ] )
            {
                ndx = 1;
            }
            else
            {
                ndx = 0;
            }
        }

        cnt = 0;
        do
        {
            /*
            || Retrieve the creation version
            */
            byte = get( vma );
            if( byte == EOF )
            {
                return 0;
            }
            vma->head[ cnt++ ] = byte;

            /*
            || Verify
            */
            if( byte != 1 )
            {
                break;
            }

            /*
            || Retrieve the creation release
            */
            byte = get( vma );
            if( byte == EOF )
            {
                return 0;
            }
            vma->head[ cnt++ ] = byte;

            /*
            || Verify
            */
            if( byte > 2 )
            {
                break;
            }

            /*
            || Retrieve the file name
            */
            for( ndx = 0; ndx < 8; ndx++ )
            {
                byte = get( vma );
                if( byte == EOF )
                {
                    return FALSE;
                }

                vma->head[ cnt ] = CONV( byte );
                if( !isprint( vma->head[ cnt++ ] ) )
                {
                    break;
                }
            }

            /*
            || Verify
            */
            if( ndx != 8 )
            {
                break;
            }

            /*
            || Retrieve the file type
            */
            for( ndx = 0; ndx < 8; ndx++ )
            {
                byte = get( vma );
                if( byte == EOF )
                {
                    return FALSE;
                }

                vma->head[ cnt ] = CONV( byte );
                if( !isprint( vma->head[ cnt++ ] ) )
                {
                    break;
                }
            }

            /*
            || Verify
            */
            if( ndx != 8 )
            {
                break;
            }

            /*
            || Retrieve the file mode
            */
            byte = get( vma );
            if( byte == EOF )
            {
                return FALSE;
            }
            byte = CONV( byte );
            vma->head[ cnt++ ] = byte;

            /*
            || Verify
            */
            if( !isalpha( byte ) )
            {
                break;
            }

            /*
            || Retrieve the file mode number
            */
            byte = get( vma );
            if( byte == EOF )
            {
                return FALSE;
            }
            byte = CONV( byte );
            vma->head[ cnt++ ] = byte;

            /*
            || Verify
            */
            if( byte < '1' || byte > '6' )
            {
                break;
            }

            /*
            || Retrieve the record length
            */
            byte = get( vma );
            if( byte == EOF )
            {
                return FALSE;
            }
            vma->head[ cnt++ ] = byte;

            byte = get( vma );
            if( byte == EOF )
            {
                return FALSE;
            }
            vma->head[ cnt++ ] = byte;

            /*
            || Retrieve the year
            */
            byte = get( vma );
            if( byte == EOF )
            {
                return FALSE;
            }
            vma->head[ cnt++ ] = cvb( byte );

            /*
            || Retrieve the month
            */
            byte = get( vma );
            if( byte == EOF )
            {
                return FALSE;
            }
            byte = cvb( byte );
            vma->head[ cnt++ ] = byte;

            /*
            || Verify
            */
            if( byte < 1 || byte > 12 )
            {
                break;
            }

            /*
            || Retrieve the day
            */
            byte = get( vma );
            if( byte == EOF )
            {
                return FALSE;
            }
            byte = cvb( byte );
            vma->head[ cnt++ ] = byte;

            /*
            || Verify
            */
            if( byte < 1 || byte > 31 )
            {
                break;
            }

            /*
            || Retrieve the hour
            */
            byte = get( vma );
            if( byte == EOF )
            {
                return FALSE;
            }
            byte = cvb( byte );
            vma->head[ cnt++ ] = byte;

            /*
            || Verify
            */
            if( byte > 23 )
            {
                break;
            }

            /*
            || Retrieve the minute
            */
            byte = get( vma );
            if( byte == EOF )
            {
                return FALSE;
            }
            byte = cvb( byte );
            vma->head[ cnt++ ] = byte;

            /*
            || Verify
            */
            if( byte > 59 )
            {
                break;
            }

            /*
            || Retrieve the second
            */
            byte = get( vma );
            if( byte == EOF )
            {
                return FALSE;
            }
            byte = cvb( byte );
            vma->head[ cnt++ ] = byte;

            /*
            || Verify
            */
            if( byte > 59 )
            {
                break;
            }

            /*
            || Retrieve the record format
            */
            byte = get( vma );
            if( byte == EOF )
            {
                return FALSE;
            }
            byte = CONV( byte );
            vma->head[ cnt++ ] = byte;

            /*
            || Verify
            */
            if( byte != 'F' && byte != 'V' )
            {
                break;
            }

            /*
            || Retrieve the flags
            */
            byte = get( vma );
            if( byte == EOF )
            {
                return FALSE;
            }
            vma->head[ cnt++ ] = byte;

            /*
            || Verify
            */
            if( byte & ~( HF_S2 | HF_ASIS | HF_Y2K | HF_EXTH ) )
            {
                break;
            }

            /*
            || Get the extended header
            */
            if( byte & HF_EXTH )
            {
                for( ndx = 0; ndx < 4; ndx++ )
                {
                    byte = get( vma );
                    if( byte == EOF )
                    {
                        return FALSE;
                    }
                    vma->head[ cnt++ ] = byte;
                }
            }

            /*
            || Looks like we've found a new header
            */
            return TRUE;

        } while( FALSE );

        unget( vma, vma->head, cnt );
    }

    return FALSE;
}

/* --------------------------------------------------------------------
|| Determines if we're running under z/VM or z/OS
*/
static void
systype( VMA *vma )
{
#if defined( __MVS__ )
    /*
    || The utsname structures on z/OS and z/VM differ in size, so to
    || be able to run a z/OS compiled module under z/VM, we add some
    || padding.
    */
    union
    {
        struct utsname un;
        char dummy[ 256 ];
    } u;

    memset( &u.un, 0, sizeof( u ) );

    uname( &u.un );

    if( strcmp( u.un.sysname, "OS/390" ) == 0 )
    {
        vma->f_zos = TRUE;
    }
    else if( strcmp( u.un.sysname, "z/VM" ) == 0 )
    {
        vma->f_zvm = TRUE;
    }

#endif
    return;
}

/* ********************************************************************
|| Public functions                                                  ||
******************************************************************** */

/* ====================================================================
|| Builds conversion table based on UCMs
*/
int
vma_setconv( void *vvma, char *fucm, char *tucm )
{
    VMA *vma = (VMA *)vvma;
    int i;
    int subchar;
    ENT tmap[ 256 ];
    ENT fmap[ 256 ];

    /*
    || Verify VMA
    */
    if( vma == NULL )
    {
        return VMAE_BADARG;
    }

    /*
    || Verify "from" UCM
    */
    if( fucm == NULL && tucm != NULL )
    {
        return seterr( VMAE_BADARG );
    }

    /*
    || Verify "to" UCM
    */
    if( tucm == NULL && fucm != NULL )
    {
        return seterr( VMAE_BADARG );
    }

    /*
    || If both are null, then reset to default tables
    */
    if( tucm == NULL && fucm == NULL )
    {
#if defined( __MVS__ )
        memcpy( vma->cmap, e2e_tab, 256 );
#else
        memcpy( vma->cmap, e2a_tab, 256 );
#endif
        return VMAE_NOERR;
    }

    /*
    || Load "from" UCM
    */
    if( !loaducm( vma, fucm, fmap, &subchar ) )
    {
        return vma->lasterr;
    }

    /*
    || Load "to" UCM
    */
    if( !loaducm( vma, tucm, tmap, &subchar ) )
    {
        return vma->lasterr;
    }

    /*
    || Make sure "to" map is sorted
    */
    qsort( &tmap, 256, sizeof( ENT ), cmp );

    /*
    || Transfer to caller's mapping
    */
    for( i = 0; i < 256; i++)
    {
        ENT *ent;

        ent = (ENT *) bsearch( &fmap[ i ],
                               tmap,
                               256,
                               sizeof( ENT ),
                               cmp );
        if( ent == NULL )
        {
            vma->cmap[ i ] = subchar;
        }
        else
        {
            vma->cmap[ i ] = ent->b;
        }
#if 0
        if( !((i+0) % 16 ) )
        {
            printf("\n");
        }
        printf("\\x%02x", vma->cmap[ i ] );
#endif
    }

    return VMAE_NOERR;
}

const static int days[] = 
{
    0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334
};

/* ====================================================================
|| Extract currently active subfile
*/
int
vma_extract( void *vvma, char *name, int mode )
{
    VMA *vma = (VMA *)vvma;
    PSUBFILE *psf;
    char openflags[ 64 ];
    struct tm bt;
    struct utimbuf ut;
    time_t ct;
    int rc;

#if defined( __MVS__ )
    fldata_t fd;
#endif

    /*
    || Verify VMA
    */
    if( vma == NULL )
    {
        return VMAE_BADARG;
    }

    /*
    || Verify name
    */
    if( name == NULL )
    {
        return seterr( VMAE_BADARG );
    }

    /*
    || Verify mode
    */
    switch( mode )
    {
        case VMAX_AUTO:
        case VMAX_TEXT:
        case VMAX_TRANS:
        case VMAX_BINARY:
        break;

        default:
            return seterr( VMAE_BADARG );
    }

    /*
    || Ensure an active subfile
    */
    psf = vma->active;
    if( psf == NULL )
    {
        return seterr( VMAE_INACT );
    }

    /*
    || Reset error
    */
    seterr( VMAE_NOERR );

    /*
    || If user requested AUTO and we haven't previously scanned the
    || subfile, then we must do so now.
    */
    if( mode == VMAX_AUTO )
    {
        if( psf->sf.dtype == VMAD_UNKNOWN )
        {
            /*
            || Don't know what type it is yet.
            */
            vma->f_text = FALSE;

            /*
            || Turn extraction off
            */
            vma->f_extract = FALSE;

            /*
            || And indicate we only want to scan first 1024 bytes
            */
            vma->f_scanning = TRUE;

            /*
            || And indicate we only want to scan first 1024 bytes
            */
            rc = extract( vma, psf->flags );

            /*
            || Disable scanning mode
            */
            vma->f_scanning = FALSE;

            /*
            || Turn extraction back on
            */
            vma->f_extract = TRUE;

            /*
            || Bail if the extraction wasn't successful
            */
            if( !rc )
            {
                return vma->lasterr;
            }

            /*
            || Remember it
            */
            psf->sf.dtype = vma->dtype;
        }

        /*
        || Set the extraction type
        */
        mode = psf->sf.dtype;
    }

    /*
    || Convert to ASCII?
    */
    vma->f_text = FALSE;
    vma->f_trans = FALSE;
    if( mode == VMAX_TEXT || mode == VMAX_TRANS )
    {
        vma->f_trans = TRUE;
#if !defined( __MVS__ )
        if( mode == VMAX_TEXT )
        {
            vma->f_text = TRUE;
        }
#endif
    }

    /*
    || Cache RECFM and LRECL
    */
    vma->recfm = psf->sf.recfm;
    vma->lrecl = psf->sf.lrecl;

    /*
    || Calculate the maximum size of the output buffer
    */
    vma->omax = ( vma->recfm == 'F' ? vma->lrecl : vma->lrecl + 4 ) +
#if defined( _WIN32 )
                ( vma->f_text ? 2 : 0 );
#else
                ( vma->f_text ? 1 : 0 );
#endif

    /*
    || Ensure LRECL is in range
    */
    if( vma->f_zos )
    {
        if( vma->recfm == 'V' && vma->omax + 4 > 32760 )
        {
            return seterr( VMAE_LRECL );
        }
    }
    else if( vma->f_zvm )
    {
        if( vma->omax > 65535 )
        {
            return seterr( VMAE_LRECL );
        }
    }

    /*
    || Build the open flags
    */
    sprintf( openflags,
             "wb"
#if defined( __MVS__ )
             ",type=record,noseek,recfm=%c,lrecl=%d,blksize=0",
             vma->recfm,
             vma->omax
#endif
           );

    /*
    || And open the output file
    */
    vma->out = fopen( name, openflags );
    if( vma->out == NULL )
    {
        return seterr( VMAE_OOPEN );
    }

    /*
    || (Re)Alocate output buffer
    */
    vma->obuf = (uchar *) malloc( vma->omax + 1 );
    if( vma->obuf == NULL )
    {
        fclose( vma->out );
        vma->out = NULL;

        return seterr( VMAE_MEM );
    }
    vma->opos = 0;

    /*
    || Extract the file
    */
    rc = extract( vma, psf->flags );

    /*
    || Get rid of the buffer
    */
    free( vma->obuf );
    vma->obuf = NULL;

#if defined( __MVS__ )
    /*
    || Retrieve the real filename before closing the file
    */
    if( rc && vma->f_zvm )
    {
        if( fldata( vma->out, NULL, &fd ) )
        {
            seterr( VMAE_TIME );
            rc = FALSE;
        }
    }
#endif

    /*
    || Close the file
    */
    fclose( vma->out );
    vma->out = NULL;

    /*
    || Attempt to set the file times
    */
    if( rc )
    {
#if defined( __MVS__ )
        if( vma->f_zos )
        {
            /* not much we can do here */
        }
        else if( vma->f_zvm )
        {
            char cmd[ 256 ];

            sprintf( cmd,
                     "DMSPLU "
                     "%s "
                     "%02d/%02d/%04d "
                     "%02d:%02d:%02d",
                     fd.__dsname,
                     vma->active->sf.month,
                     vma->active->sf.day,
                     vma->active->sf.year,
                     vma->active->sf.hour,
                     vma->active->sf.minute,
                     vma->active->sf.second );

            if( system( cmd ) )
            {
                 seterr( VMAE_TIME );
            }
        }
        else
#endif
        {
            /*
            || Set the last access and modification times
            */
            bt.tm_sec = psf->sf.second;
            bt.tm_min = psf->sf.minute;
            bt.tm_hour = psf->sf.hour;
            bt.tm_mday = psf->sf.day;
            bt.tm_mon = psf->sf.month - 1;
            bt.tm_year = psf->sf.year - 1900;
            bt.tm_wday = 0;
            bt.tm_yday = 0;
            bt.tm_isdst = -1;

            ct = mktime( &bt );
            if( ct != (time_t) -1 )
            {
                ut.actime = ct;
                ut.modtime = ct;

                if( utime( name, &ut ) == -1 )
                {
                    seterr( VMAE_TIME );
                }
            }
            else
            {
                seterr( VMAE_TIME );
            }
        }
    }

    return vma->lasterr;
}

/* ====================================================================
||
*/
int
vma_setactive( void *vvma, SUBFILE *sf )
{
    VMA *vma = (VMA *) vvma;
    PSUBFILE *psf;

    /*
    || Verify VMA
    */
    if( vma == NULL )
    {
        return VMAE_BADARG;
    }

    /*
    || Verify subfile
    */
    if( sf == NULL )
    {
        return seterr( VMAE_BADARG );
    }

    /*
    || Make this subfile the active one
    */
    for( psf = vma->subfiles; psf != NULL; psf = psf->next )
    {
        if( &psf->sf == sf )
        {
            break;
        }
    }

    /*
    || Processed all subfiles
    */
    if( psf == NULL )
    {
        return seterr( VMAE_NOTFOUND );
    }

    /*
    || Set the active subfile
    */
    vma->active = psf;

    /*
    || Success
    */
    return seterr( VMAE_NOERR );
}

/* ====================================================================
||
*/
int
vma_next( void *vvma, SUBFILE **sfp )
{
    VMA *vma = (VMA *) vvma;

    /*
    || Verify VMA
    */
    if( vma == NULL )
    {
        return VMAE_BADARG;
    }

    /*
    || Verify subfile
    */
    if( sfp == NULL )
    {
        return seterr( VMAE_BADARG );
    }

    /*
    || Reset error
    */
    seterr( VMAE_NOERR );

    if( vma->active == NULL )
    {
        return seterr( VMAE_INACT );
    }

    /*
    || Set the next active file
    */
    vma->active = vma->active->next;

    /*
    || Processed all subfiles
    */
    if( vma->active == NULL )
    {
        return seterr( VMAE_NOMORE );
    }

    /*
    || Store subfile ptr (possibly NULL)
    */
    *sfp = &vma->active->sf;

    /*
    || Success
    */
    return seterr( VMAE_NOERR );
}

/* ====================================================================
||
*/
int
vma_first( void *vvma, SUBFILE **sfp )
{
    VMA *vma = (VMA *) vvma;

    /*
    || Verify VMA
    */
    if( vma == NULL )
    {
        return VMAE_BADARG;
    }

    /*
    || Verify subfile
    */
    if( sfp == NULL )
    {
        return seterr( VMAE_BADARG );
    }

    /*
    || Make this subfile the active one
    */
    vma->active = vma->subfiles;

    /*
    || Processed all subfiles
    */
    if( vma->active == NULL )
    {
        return seterr( VMAE_NOMORE );
    }

    /*
    || Store subfile ptr (possibly NULL)
    */
    *sfp = &vma->active->sf;

    /*
    || Success
    */
    return seterr( VMAE_NOERR );
}

/* ====================================================================
||
*/
void
vma_close( void *vvma )
{
    VMA *vma = (VMA *) vvma;
    PSUBFILE *psf;

    /*
    || Bail if we weren't passed a VMA
    */
    if( vma == NULL )
    {
        return;
    }

    /*
    || Close the input file
    */
    if( vma->in != NULL )
    {
        fclose( vma->in );
    }

    /*
    || Close the output file
    */
    if( vma->out != NULL )
    {
        fclose( vma->out );
    }

    /*
    || Free all of the SUBFILEs
    */
    while( vma->subfiles != NULL )
    {
        psf = vma->subfiles;
        vma->subfiles = psf->next;

        free( psf );
    }

    /*
    || Free the output buffer
    */
    if( vma->obuf != NULL )
    {
        free( vma->obuf );
    }

    /*
    || And, finally, free the VMA itself
    */
    free( vma );

    return;
}

/* ====================================================================
||
*/
int
vma_open( char *name, int size, void **vvma )
{
    VMA *vma = NULL;
    PSUBFILE *psf;
    PSUBFILE *lpsf;
    int i;
    int ec = VMAE_NOERR;

    /*
    || Verify args
    */
    if( name == NULL || vvma == NULL )
    {
        ec = VMAE_BADARG;
        goto error;
    }

    /*
    || Initialize vvma
    */
    *vvma = NULL;

    /*
    || Allocate our handle
    */
    vma = (VMA *) calloc( 1, sizeof( VMA ) );
    if( vma == NULL )
    {
        ec = VMAE_MEM;
        goto error;
    }

    /*
    || Set default conversion table
    */
    vma_setconv( vma, NULL, NULL );

    /*
    || Get the system type
    */
    systype( vma );

    /*
    || Open the VMARC file
    */
    vma->in = fopen( name, "rb" );
    if( vma->in == NULL )
    {
        ec = VMAE_IOPEN;
        goto error;
    }

    /*
    || Turn off extraction in case we are to retrieve sizes
    */
    vma->f_extract = FALSE;

    /*
    || Build list of subfiles
    */
    lpsf = NULL;

    while( locate_file( vma ) )
    {
        /*
        || Allocate a new subfile
        */
        psf = (PSUBFILE *) calloc( 1, sizeof( PSUBFILE ) );
        if( psf == NULL )
        {
            ec = VMAE_MEM;
            goto error;
        }

        /*
        || Link it in
        */
        if( lpsf == NULL )
        {
            vma->subfiles = psf;
        }
        else
        {
            lpsf->next = psf;
        }
        lpsf = psf;

        /*
        || Copy header to subfile
        */
        psf->sf.ver     = vma->head[ H_VER      ];
        psf->sf.rel     = vma->head[ H_REL      ];

        sprintf( (char *) psf->sf.meth,
                 "%s",
                 ( vma->head[ H_FLAGS ] & HF_ASIS ? "ASIS" :
                 ( vma->head[ H_FLAGS ] & HF_S2 ? "S2" :
                 "LZW" ) ) );
        for( i = 0; i < 8 && vma->head[ H_FN + i ] != ' '; i++ )
        {
            psf->sf.fn[ i ] = vma->head[ H_FN + i ];
        }
        for( i = 0; i < 8 && vma->head[ H_FT + i ] != ' '; i++ )
        {
            psf->sf.ft[ i ] = vma->head[ H_FT + i ];
        }
        for( i = 0; i < 2 && vma->head[ H_FM + i ] != ' '; i++ )
        {
            psf->sf.fm[ i ] = vma->head[ H_FM + i ];
        }
        psf->sf.year = vma->head[ H_YEAR ] + 1900 +
                       ( ( vma->head[ H_FLAGS ] & HF_Y2K ) ? 100 : 0 );
        psf->sf.month   = vma->head[ H_MONTH    ];
        psf->sf.day     = vma->head[ H_DAY      ];
        psf->sf.hour    = vma->head[ H_HOUR     ];
        psf->sf.minute  = vma->head[ H_MINUTE   ];
        psf->sf.second  = vma->head[ H_SECOND   ];
        psf->sf.recfm   = vma->head[ H_RECFM    ];
        psf->flags      = vma->head[ H_FLAGS    ];

        /*
        || Hack for non-Y2K compliant files.  Yes, they ARE still being
        || created!  Come on folks, upgrade your VMARC to at least
        || V1R2P021.  :-)
        */
        if( psf->sf.year < 1960 )
        {
            psf->sf.year += 100;
        }

        /*
        || Construct the LRECL
        */
        if( vma->head[ H_FLAGS ] & HF_EXTH )
        {
            psf->sf.lrecl = ( vma->head[ H_XRECL + 0 ] << 24 ) |
                         ( vma->head[ H_XRECL + 1 ] << 16 ) |
                         ( vma->head[ H_XRECL + 2 ] << 8  ) |
                         ( vma->head[ H_XRECL + 3 ]       );
        }
        else
        {
            psf->sf.lrecl = ( vma->head[ H_LRECL + 0 ] << 8  ) |
                         ( vma->head[ H_LRECL + 1 ]       );
        }

        /*
        || Remember where the data starts
        */
        psf->offset = mytell( vma );

        /*
        || Retrieve the sizes if requested
        */
        if( size )
        {
            vma->active = psf;
            if( !extract( vma, psf->flags ) )
            {
                ec = vma->lasterr;
                goto error;
            }
            vma->active = NULL;
        }
    }

    if( ferror( vma->in ) )
    {
        ec = VMAE_RERR;
        goto error;
    }

    /*
    || Turn extraction back on
    */
    vma->f_extract = TRUE;

    /*
    || Store the VMA ptr
    */
    *( (VMA ** ) vvma ) = vma;

    /*
    || Success
    */
    return seterr( VMAE_NOERR );

error:

    /*
    || Use vma_close() to cleanup
    */
    vma_close( vma );

    return ec;
}
