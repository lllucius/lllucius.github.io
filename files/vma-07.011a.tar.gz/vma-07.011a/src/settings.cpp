/* ====================================================================
||
|| VMAGui - GUI viewer/extractor for VMARC Hives
||
|| This little utility allows you to view and extract subfiles from
|| archives in VMARC format.
||
|| Written by:  Leland Lucius (vma@homerow.net>
||
|| Copyright:  Public Domain (just use your conscience)
||
==================================================================== */

// ====================================================================
// headers
// ====================================================================

// For compilers that support precompilation, includes "wx/wx.h".
#include <wx/wxprec.h>

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include <wx/wx.h>
#endif

#include <wx/config.h>
#include <wx/tokenzr.h>
#include <wx/statline.h>
#include <wx/cshelp.h>

#if defined( _WIN32 )
#include <shlwapi.h>
#include <shlobj.h>
#endif

#include "settings.h"

#include "res/find16.xpm"

// ====================================================================
// Event table
// ====================================================================
BEGIN_EVENT_TABLE( Settings, wxDialog )

    // Button handlers
    EVT_BUTTON(         wxID_OK,    Settings::OnOk           )
    EVT_BUTTON(         ID_UPDATE,  Settings::OnUpdate       )
    EVT_BUTTON(         ID_REMOVE,  Settings::OnRemove       )
    EVT_BUTTON(         ID_TXTBRO,  Settings::OnTextBrowse   )
    EVT_BUTTON(         ID_BINBRO,  Settings::OnBinaryBrowse )
    EVT_BUTTON(         ID_FROMBRO, Settings::OnFromBrowse   )
    EVT_BUTTON(         ID_TOBRO,   Settings::OnToBrowse     )

END_EVENT_TABLE()

// ====================================================================
// Constructor
// ====================================================================
Settings::Settings( wxWindow *parent, int id, wxString title )
    : wxDialog( parent, id, title )
{
    wxBoxSizer *vSizer;
    wxBoxSizer *hSizer;
    wxFlexGridSizer *fSizer;
    wxStaticBoxSizer *sSizer;
    wxStaticText *sText;
    wxBitmapButton *BBtn;
    wxButton *Btn;

    // Base grouping
    vSizer = new wxBoxSizer( wxVERTICAL );

    // Viewers grouping
    sSizer = new wxStaticBoxSizer( wxVERTICAL,
                                   this,
                                   wxT( "Viewers" ) );

    fSizer = new wxFlexGridSizer( 3 );
    fSizer->AddGrowableCol( 1 );

    // Text viewer grouping
    sText = new wxStaticText( this,
                              wxID_ANY,
                              wxT( "Te&xt" ) );

    fSizer->Add( sText, 0, wxALIGN_CENTER_VERTICAL | wxALIGN_RIGHT );

    m_TxtViewer = new wxTextCtrl( this,
                                  wxID_ANY,
                                  wxT( "Notepad" ) );

    fSizer->Add( m_TxtViewer, 0, wxEXPAND | wxALL, 3 );

    BBtn = new wxBitmapButton( this,
                               ID_TXTBRO,
                               wxBitmap( find16_xpm ) );
    BBtn->SetName( "Browse for file..." );
    BBtn->SetToolTip( "Browse for file..." );

    fSizer->Add( BBtn, 0, wxALIGN_CENTER_VERTICAL );

    // Binary viewer grouping
    sText = new wxStaticText( this,
                              wxID_ANY,
                              wxT( "Bi&nary" ) );
         
    fSizer->Add( sText, 0, wxALIGN_CENTER_VERTICAL | wxALIGN_RIGHT );

    m_BinViewer = new wxTextCtrl( this,
                                  wxID_ANY,
                                  wxT( "Notepad" ) );

    fSizer->Add( m_BinViewer, 0, wxEXPAND | wxALL, 3 );

    BBtn = new wxBitmapButton( this,
                               ID_BINBRO,
                               wxBitmap( find16_xpm ) );
    BBtn->SetName( "Browse for file..." );
    BBtn->SetToolTip( "Browse for file..." );
         
    fSizer->Add( BBtn, 0, wxALIGN_CENTER_VERTICAL );

    sSizer->Add( fSizer, 0, wxEXPAND | wxLEFT | wxRIGHT, 3 );

    vSizer->Add( sSizer, 0, wxEXPAND | wxALL, 5 );

    // Extensions grouping
    sSizer = new wxStaticBoxSizer( wxVERTICAL,
    								        this,
                                   wxT( "&Extensions" ) );

    // Extensions edit grouping
    hSizer = new wxBoxSizer( wxHORIZONTAL );

    m_Exts = new wxTextCtrl( this,
                             wxID_ANY,
                             wxT( "*.vmarc;*.vma" ) );

    hSizer->Add( m_Exts, 1 );

    sSizer->Add( hSizer, 1, wxEXPAND | wxALL, 3 );

    // Extensions button grouping
    hSizer = new wxBoxSizer( wxHORIZONTAL );

    Btn = new wxButton( this,
                        ID_UPDATE,
                        wxT( "&Update" ) );

    hSizer->Add( Btn, 0 );

    sText = new wxStaticText( this,
                              wxID_ANY,
                              wxT( "Separate with ';'" ),
                              wxDefaultPosition,
                              wxDefaultSize,
                              wxALIGN_CENTRE );
         
    hSizer->Add( sText, 1, wxALIGN_CENTER_VERTICAL | wxALL, 3 );

    Btn = new wxButton( this,
                        ID_REMOVE,
                        wxT( "&Remove" ) );

    hSizer->Add( Btn, 0 );

    sSizer->Add( hSizer, 0, wxEXPAND | wxLEFT | wxRIGHT, 3 );

    vSizer->Add( sSizer, 0, wxEXPAND | wxALL, 5 );
    
    // Conversion grouping
    sSizer = new wxStaticBoxSizer( wxVERTICAL,
											  this,
                            		  wxT( "Conversion UCMs" ) );

    fSizer = new wxFlexGridSizer( 3 );
    fSizer->AddGrowableCol( 1 );

    // From UCM grouping
    sText = new wxStaticText( this,
                              wxID_ANY,
                              wxT( "&From" ) );
         
    fSizer->Add( sText, 0, wxALIGN_CENTER_VERTICAL | wxALIGN_RIGHT );

    m_FromUCM = new wxTextCtrl( this,
                                wxID_ANY,
                                wxT( "" ) );

    fSizer->Add( m_FromUCM, 0, wxEXPAND | wxALL, 3 );

    BBtn = new wxBitmapButton( this,
                               ID_FROMBRO,
                               wxBitmap( find16_xpm ) );
    BBtn->SetName( "Browse for file..." );
    BBtn->SetToolTip( "Browse for file..." );
         
    fSizer->Add( BBtn, 0, wxALIGN_CENTER_VERTICAL );

    // To UCM grouping
    sText = new wxStaticText( this,
                              wxID_ANY,
                              wxT( "&To" ) );

    fSizer->Add( sText, 0, wxALIGN_CENTER_VERTICAL | wxALIGN_RIGHT );

    m_ToUCM = new wxTextCtrl( this,
                              wxID_ANY,
                              wxT( "" ) );

    fSizer->Add( m_ToUCM, 0, wxEXPAND | wxALL, 3 );

    BBtn = new wxBitmapButton( this,
                               ID_TOBRO,
                               wxBitmap( find16_xpm ) );
    BBtn->SetName( "Browse for file..." );
    BBtn->SetToolTip( "Browse for file..." );
         
    fSizer->Add( BBtn, 0, wxALIGN_CENTER_VERTICAL );

    sSizer->Add( fSizer, 0, wxEXPAND | wxLEFT | wxRIGHT, 3 );

    vSizer->Add( sSizer, 0, wxEXPAND | wxALL, 5 );

    // Default list action
    hSizer = new wxBoxSizer( wxHORIZONTAL );

    sText = new wxStaticText( this,
                              wxID_ANY,
                              wxT( "&List double click/enter action" ) );
         
    hSizer->Add( sText, 1, wxALIGN_CENTER_VERTICAL | wxLEFT | wxRIGHT, 5 );

    m_Action = new wxComboBox( this,
                               wxID_ANY,
                               wxT( "View" ),
                               wxDefaultPosition,
                               wxDefaultSize,
                               0,
                               NULL,
                               wxCB_READONLY );

    m_Action->Append( wxT( "View" ) );
    m_Action->Append( wxT( "Extract" ) );

    hSizer->Add( m_Action, 0, wxCENTER | wxLEFT | wxRIGHT, 5 );

    vSizer->Add( hSizer, 0, wxEXPAND | wxALL, 3 );
    
    // Full scan options
    hSizer = new wxBoxSizer( wxHORIZONTAL );

    m_Stats = new wxCheckBox( this,
                              wxID_ANY,
                              wxT( "&Gather subfile types and sizes during open (slower)" ),
                              wxDefaultPosition,
                              wxDefaultSize,
                              wxALIGN_RIGHT );

    hSizer->Add( m_Stats, 0, wxLEFT | wxRIGHT, 3 );

    vSizer->Add( hSizer, 0, wxEXPAND | wxALL, 3 );

    // Divider
    hSizer = new wxBoxSizer( wxHORIZONTAL );

    hSizer->Add( new wxStaticLine( this ), 1 );
    
    vSizer->Add( hSizer, 0, wxEXPAND | wxALL, 5 );

    // Dialog button grouping
	 vSizer->Add( CreateButtonSizer( wxOK | wxCANCEL ),
	              0,
	              wxALIGN_RIGHT | wxBOTTOM, 5 );

    SetSizerAndFit( vSizer );

    vSizer->SetSizeHints( this );

    // Get access to our config manager
    m_Config = wxConfig::Get();

    // Load required settings
    m_Config->SetPath( "/Settings" );

    m_Stats->SetValue( m_Config->Read( _T( "Subfile Stats" ), true ) );

    m_TxtViewer->SetValue( m_Config->Read( _T( "Text Viewer" ), _T( "Notepad" ) ) );

    m_BinViewer->SetValue( m_Config->Read( _T( "Binary Viewer" ), _T( "Notepad" ) ) );

    m_FromUCM->SetValue( m_Config->Read( _T( "From UCM" ), _T( "" ) ) );

    m_ToUCM->SetValue( m_Config->Read( _T( "To UCM" ), _T( "" ) ) );

    m_Exts->SetValue( m_Config->Read( _T( "Extensions" ), _T( ".vma;.vmarc" ) ) );

    m_Action->SetValue( m_Config->Read( _T( "Default Action" ), _T( "View" ) ) );
}

// ====================================================================
// Ok button clicked
// ====================================================================
void Settings::OnOk( wxCommandEvent& WXUNUSED( event ) )
{
    // Set active subkey
    m_Config->SetPath( "/Settings" );

    // Write all settings
    m_Config->Write( "Text Viewer",
                     m_TxtViewer->GetValue() );

    m_Config->Write( "Binary Viewer",
                     m_BinViewer->GetValue() );

    m_Config->Write( "From UCM",
                     m_FromUCM->GetValue() );

    m_Config->Write( "To UCM",
                     m_ToUCM->GetValue() );

    m_Config->Write( "Default Action",
                     m_Action->GetValue() );

    m_Config->Write( "Subfile Stats",
                     m_Stats->GetValue() );

    // Close down the dialog
    Close( true );

    return;
}

// ====================================================================
// Update button clicked
// ====================================================================
void Settings::OnUpdate( wxCommandEvent& event )
{

#if defined( _WIN32 )

    wxString exts = m_Exts->GetValue();
    wxStringTokenizer st( exts, _T( ";" ) );
    wxString ext;
    wxString app;
    wxString val;
    int cnt;
    
    // Remove existing extensions
    OnRemove( event );

    // Nothing left to do if no extensions specified
    if( exts.IsEmpty() )
    {
        return;
    }

    // Get a fully qualified path to our app
    ::PathCanonicalize( app.GetWriteBuf( MAX_PATH ), wxTheApp->argv[ 0 ] );
    app.UngetWriteBuf();

    // Build the application entry
    ::SHSetValue( HKEY_CLASSES_ROOT,
                  "VMARC_Hive",
                  "",
                  REG_SZ,
                  "VMARC Hive",
                  sizeof( "VMARC Hive" ) - 1 );

    ::SHSetValue( HKEY_CLASSES_ROOT,
                  "VMARC_Hive\\shell",
                  "",
                  REG_SZ,
                  "open",
                  sizeof( "open" ) - 1 );

    ::SHSetValue( HKEY_CLASSES_ROOT,
                  "VMARC_Hive\\shell\\open",
                  "",
                  REG_SZ,
                  "Open",
                  sizeof( "Open" ) - 1 );

    val = app + " \"%1\"";
    ::SHRegSetPath( HKEY_CLASSES_ROOT,
                    "VMARC_Hive\\shell\\open\\command",
                    "",
                    val,
                    0 );

    ::SHSetValue( HKEY_CLASSES_ROOT,
                  "VMARC_Hive\\shell\\extract",
                  "",
                  REG_SZ,
                  "Extract to...",
                  sizeof( "Extract to..." ) - 1 );
 
    val = app + " /x \"%1\"";
    ::SHRegSetPath( HKEY_CLASSES_ROOT,
                    "VMARC_Hive\\shell\\extract\\command",
                    "",
                    val,
                    0 );

    val = app + ",0";
    ::SHRegSetPath( HKEY_CLASSES_ROOT,
                    "VMARC_Hive\\DefaultIcon",
                    "",
                    val,
                    0 );

    // Add each extension
    cnt = 0;
    while( st.HasMoreTokens() )
    {
        // Extract the next ";" delimited token
        ext = st.GetNextToken().Strip( wxString::both );
        if( ext.Length() == 0 )
        {
            continue;
        }

        // Remove leading "*", if any
        if( ext[ 0 ] == '*' )
        {
            ext.Remove( 0, 1 );
        }

        // Remove leading ".", if any
        if( ext[ 0 ] == '.' )
        {
            ext.Remove( 0, 1 );
        }

        // Associate the extension with our application
        ::SHSetValue( HKEY_CLASSES_ROOT,
                      '.' + ext,
                      "",
                      REG_SZ,
                      "VMARC_Hive",
                      sizeof( "VMARC_Hive" ) - 1 );

        // Track number associated
        cnt++;
    }

    // Tell everyone the associations changed
    SHChangeNotify( SHCNE_ASSOCCHANGED, SHCNF_IDLIST, 0, 0 );

    // Store extensions in registry
    //
    // NOTE:  Shouldn't need to do this if we scanned the registry for
    //        currently associated.
    m_Config->Write( "Extensions",
                     exts );

    // Tell 'em what happened
    exts.Printf( "%d extensions registered", cnt );
    wxMessageBox( exts, "Helpful Message" );

#endif

    return;
}

// ====================================================================
// Remove button clicked
// ====================================================================
void Settings::OnRemove( wxCommandEvent& event )
{
#if defined( _WIN32 )

    char buf[ MAX_PATH ];
    char val[ MAX_PATH ];
    DWORD len;
    DWORD ndx;
    DWORD type;
    bool ffirst = 0;

    // Get rid of the program entry
    ::SHDeleteKey( HKEY_CLASSES_ROOT,
                   "VMARC_Hive" );

    // Scan all HKCR entries beginning with "."
    ndx = 0;
    len = sizeof( buf );
    while( ::SHEnumKeyEx( HKEY_CLASSES_ROOT, ndx, buf, &len ) == ERROR_SUCCESS )
    {
        // Ignore until first extension, then stop when last is processed
        if( buf[ 0 ] != '.' )
        {
            if( ffirst )
            {
                break;
            }
        }
        else
        {
            ffirst = 1;
        }

        // Get the default value
        len = sizeof( val );
        type = REG_SZ;
        SHGetValue( HKEY_CLASSES_ROOT,
                      buf,
                      "",
                      &type,
                      val,
                      &len );

        // Delete it if it's ours
        if( strcmp( val, "VMARC_Hive" ) == 0 )
        {
            ::SHDeleteKey( HKEY_CLASSES_ROOT,
                           buf );
        }

        // Prepare for next
        ndx++;
        len = sizeof( buf ) - 1;
    }

    // Tell everyone the associations changed
    ::SHChangeNotify( SHCNE_ASSOCCHANGED, SHCNF_IDLIST, 0, 0 );

    // Bypass if we were called from OnUpdate()
    if( event.GetId() == ID_REMOVE )
    {
        // Clear edit box
        m_Exts->SetValue( "" );

        // And registry setting
        m_Config->Write( "Extensions",
                         "" );

        // Let 'em know what happened
        wxMessageBox( "All extensions removed.\n"
                      "You must click 'Update' to re-associate.",
                      "Helpful Message" );
    }

#endif

    return;
}

// ====================================================================
// Browse for text viewer clicked
// ====================================================================
void Settings::OnTextBrowse( wxCommandEvent& WXUNUSED( event ) )
{
    wxFileDialog fd( this,
                     "Choose your favorite text viewing program",
                     m_TxtViewer->GetValue(),
                     "",
                     "All Files|*.*" );

    // Show the dialog
    if( fd.ShowModal() != wxID_OK )
    {
        return;
    }

    // Store path in edit control
    m_TxtViewer->SetValue( fd.GetPath() );

    return;
}

// ====================================================================
// Browse for binary viewer clicked
// ====================================================================
void Settings::OnBinaryBrowse( wxCommandEvent& WXUNUSED( event ) )
{
    wxFileDialog fd( this,
                     "Choose your favorite binary viewing program",
                     m_BinViewer->GetValue(),
                     "",
                     "All Files|*.*" );

    // Show the dialog
    if( fd.ShowModal() != wxID_OK )
    {
        return;
    }

    // Store path in edit control
    m_BinViewer->SetValue( fd.GetPath() );

    return;
}

// ====================================================================
// Browse for source UCM clicked
// ====================================================================
void Settings::OnFromBrowse( wxCommandEvent& WXUNUSED( event ) )
{
    wxFileDialog fd( this,
                     "Select the source UCM",
                     m_FromUCM->GetValue(),
                     "",
                     "All Files|*.*" );

    // Show the dialog
    if( fd.ShowModal() != wxID_OK )
    {
        return;
    }

    // Store path in edit control
    m_FromUCM->SetValue( fd.GetPath() );

    return;
}

// ====================================================================
// Browse for destination UCM clicked
// ====================================================================
void Settings::OnToBrowse( wxCommandEvent& WXUNUSED( event ) )
{
    wxFileDialog fd( this,
                     "Select the target UCM",
                     m_ToUCM->GetValue(),
                     "",
                     "All Files|*.*" );

    // Show the dialog
    if( fd.ShowModal() != wxID_OK )
    {
        return;
    }

    // Store path in edit control
    m_ToUCM->SetValue( fd.GetPath() );

    return;
}
