#if !defined( _VERSION_H )
#define _VERSION_H
#define VERSION "07.011a"
#define FILEVER 07,012,0,1
#define PRODVER 07,012,0,1
#define STRFILEVER "07.011a\0"
#define STRPRODVER "07.011a\0"
#endif
