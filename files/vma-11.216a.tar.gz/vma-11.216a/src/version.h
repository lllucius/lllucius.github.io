#if !defined( _VERSION_H )
#define _VERSION_H
#define LIBVER  "11.216a"
#define VERSION wxT( "11.216a" )
#define FILEVER 11,217,0,1
#define PRODVER 11,217,0,1
#define STRFILEVER "11.216a\0"
#define STRPRODVER "11.216a\0"
#endif
